### Name: test.axes
### Title: Test individual axes in RDA
### Aliases: test.axes
### Keywords: multivariate

### ** Examples

## Analysis of Table 11.3 of Legendre and Legendre (1998, p. 590)  
data(Table.11.3)
Y = Table.11.3[,1:6]
X = Table.11.3[,7:10]
out = test.axes(Y, X, nperm=999)
out$test.axes

## Analysis of the spider data  
data(spiders.spe)
data(spiders.env) 
# Hellinger transformation of the species abundance data prior to RDA
library(vegan)
spiders.hel = decostand(spiders.spe, "hellinger")
out = test.axes(spiders.hel, spiders.env, nperm=499)
out$test.axes

## Partial RDA of the spider data  
out = test.axes(spiders.hel, spiders.env[,-1], spiders.env[,1], nperm=499)
out$test.axes



