/*
* --------------------------------------------* 
* Computation of the Robinson and Foulds      *
* topological distance between two (or more)  *
* trees given their distance matrices         *
*                                             *
* Input data file format:                     *
* 1. Number of objects (matrix size) n        *
* 2. A sequence of m squared additive         *
*    distance matrices of size n by n         *
*    assosiated with trees                    *
*                                             *
* Output data:                                *
* 1. A sequence of m-1 integer numbers        *
*    containing the Robinson and Foulds       * 
*    distances between the tree associated    *
*    with the first matrix and all the other  *
*    trees associated with the following ones *
*                                             *    
* Vladimir Makarenkov                         *
* University of Montreal, September 1999      *
* --------------------------------------------*
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>


unsigned int n;
FILE *Output1;

/* Function's Propotypes */

void odp(double**,int*,int*,int*);
int Bipartition_Table(double **, int **,int*);
int Table_Comparaison(int**,int**,int*,int*,int,int);

/* Main function */
int main (void)
{

 int i,j,iii,MatrixNumber,RF,**B,**BI,*PLACE1,*PLACE2,m,m1;
 double **DI,**D,c; 
 FILE *data;
 char source[20],source1[20],CH;
 
  printf("* ---------------------------------------------*\n"); 
  printf("* Computation of the Robinson and Foulds       *\n");
  printf("* topological distance between two (or more)   *\n");
  printf("* trees given their distance matrices.         *\n");
  printf("*                                              *\n");
  printf("* Input data file format:                      *\n");
  printf("* 1. Number of objects (matrix size) n.        *\n");
  printf("* 2. A sequence of m squared additive distance *\n");
  printf("*     matrices of size n by n assosiated       *\n");
  printf("*     with trees.                              *\n");
  printf("*                                              *\n"); 
  printf("* Output data:                                 *\n");
  printf("* 1. A sequence of m-1 integer numbers         *\n");
  printf("*    containing the Robinson and Foulds        *\n"); 
  printf("*    distances between the tree associated     *\n");
  printf("*    with the first matrix and all the other   *\n");
  printf("*    trees associated with the following ones. *\n");
  printf("*                                              *\n");    
  printf("* Vladimir Makarenkov, University of Montreal, *\n");
  printf("* September 1999                               *\n");
  printf("* ---------------------------------------------*\n\n");

 
  printf("Enter the input file name for additive distance matrices\n\n");
  scanf("%s", source);
  if ((data=fopen(source,"r"))==0) { printf("\nFile %s was not found ", source); exit(0); } 
  printf("\n\n");
  
  printf("Enter the output file name for the obtaining Robinson and Foulds topological distances between the first matrix in the input file and the following ones \n\n");
  scanf("%s", source1);
  printf("\n\n");

  do {
  printf("Enter the number of matrices to analyze (including the first one)\n\n");
  scanf("%d",&MatrixNumber);
  printf("\n\n");
  if (MatrixNumber<=1) printf("You must analyse at least two additive distance matrices\n\n");
  } while (MatrixNumber<=1); 
  
  
   fscanf(data,"%d",&n);
   
    /* Memory allocation */
   D=(double **) malloc((n+1)*sizeof(double*));
   DI=(double **) malloc((n+1)*sizeof(double*));
   B=(int **) malloc((2*n-2)*sizeof(int*));
   BI=(int **) malloc((2*n-2)*sizeof(int*));
   PLACE1=(int *) malloc((2*n-2)*sizeof(int));
   PLACE2=(int *) malloc((2*n-2)*sizeof(int));

   for (i=0;i<=2*n-2;i++)
   {
    if (i<=n) { D[i]=(double*)malloc((n+1)*sizeof(double));
    DI[i]=(double*)malloc((n+1)*sizeof(double)); }
    B[i]=(int *) malloc((2*n-2)*sizeof(int));
    BI[i]=(int *) malloc((2*n-2)*sizeof(int));
  
    if (i<=n) {if ((D[i]==NULL)||(DI[i]==NULL))
    {
     printf(" Data matrix is too large\n "); 
     exit(1);
    }}
        
    if ((B[i]==NULL)||(BI[i]==NULL))
    {
     printf(" Data matrix is too large\n "); 
     exit(1);
    }    
    
   }
  
  
  for (iii=1;iii<=MatrixNumber;iii++)
  {
   
   printf("\n Matrix %d \n",iii);
   
// Read dissimilarity matrices DI or D
 if (iii!=1) {
 for (i=1; i<=n; i++)
 {
  	for (j=1; j<=n; j++)
    {
  		fscanf(data,"%lf",&c);
  		DI[i][j]=c; 
    }
    DI[i][i]=0;
  }
  DI[0][0]=0;}
  
 else {
 for (i=1; i<=n; i++)
 {
  	for (j=1; j<=n; j++)
    {
        fscanf(data,"%lf",&c);
  		D[i][j]=c;     
  	}
    D[i][i]=0;
  }
  D[0][0]=0; }
  
/* Call of procedure for computation of the ordered bipartition table and the matrix comparaison */
    if (iii==2) Output1=fopen(source1,"w");    
    if (iii==1) { m=Bipartition_Table(D,B,PLACE1); if (m==0)  exit(1);}
    if (iii>1) { 
                 m1=Bipartition_Table(DI,BI,PLACE2); if (m1==0)  exit(1);
                 RF=Table_Comparaison(B,BI,PLACE1,PLACE2,m,m1);
                 fprintf(Output1,"%d \n",RF);                              
               }


 if ((iii<MatrixNumber)&&((CH=getc(data))==EOF)) { printf("\n\nError\nBad matrix number"); fclose (data);
                                                  if (iii>2) { fclose (Output1); printf("\n\nResults in the Output file");}
                                                               exit(1);
                                                  }  
 }
 fclose (data);
 fclose (Output1); 
 printf("\n\n");  
 printf("Results in the Output file");

}




/* Computing a circular order X of n objects of the distance matrix D starting from the objects i1 and i2 */

void odp(double **D,int *X,int *i1,int *j1)
{
 double S1,S;
 int i,j,k,a,*Y1;
 
 Y1=(int *) malloc((n+1)*sizeof(int));
 
 for(i=1;i<=n;i++)
  Y1[i]=1;
  
 X[1]=*i1;
 X[n]=*j1;
 if (n==2) return;
 Y1[*i1]=0;
 Y1[*j1]=0;
 for(i=0;i<=n-3;i++)
 { a=2;
   S=0;
   for(j=1;j<=n;j++)
   { if (Y1[j]>0)
    {
      S1= D[X[n-i]][X[1]]-D[j][X[1]]+D[X[n-i]][j];
      if ((a==2)||(S1<=S))
      {
        S=S1;
        a=1;
        X[n-i-1]=j;
        k=j;
      }
    }
   }
   Y1[k]=0;
 }
   free(Y1);
}


/* Computation of an ordered bipartition table B(2n-3,n) and its rank list PLACE(2n-3)
  for the tree associated with an additive distance matrix D */

int Bipartition_Table (double **D, int **B, int *PLACE)
{
 
 int i,j,k,l,l1,*MaxCol,*X,EdgeNumberPath,m,uv,PlaceNumber,edge,*Path,M,F;
 double S,DIS,DIS1,*LengthPath;
 double EPS=1.e-5;
 double EPS1=1.e-2;
 
 /* Memory allocation */
 
  MaxCol=(int *)malloc((2*n-2)*sizeof(int));
  X=(int *)malloc((n+1)*sizeof(int));
  LengthPath=(double *)malloc((2*n-2)*sizeof(double));
  Path=(int *)malloc((2*n-2)*sizeof(int));
  
 /* Computation of a circular order X for D */     
  
 i=1; j=n; odp(D,X,&i,&j);
 
 /* Initialization */ 
 for (i=1; i<=2*n-3; i++)
 {
  MaxCol[i]=0;
  PLACE[i]=0;
  for (j=1;j<=n;j++)
     B[i][j]=0;  
 }
 B[1][X[2]]=1; MaxCol[1]=X[2]; Path[1]=1; PlaceNumber=1;
 PLACE[1]=1; LengthPath[1]=D[X[1]][X[2]]; EdgeNumberPath=1; m=1;
 
/* The main loop */

 for(k=2;k<=n-1;k++)
 {  
  /* Point 2.1 of the algorithm (see the referenced article by Makarenkov and Leclerc) */
  
  DIS=(D[X[1]][X[k]]+D[X[k]][X[k+1]]-D[X[1]][X[k+1]])/2; 
  DIS1=(D[X[1]][X[k+1]]+D[X[k]][X[k+1]]-D[X[1]][X[k]])/2;
  
  if ((DIS<=-EPS1)||(DIS1<=-EPS1)) { printf("\n This is not an additive distance \n");
                                     free(MaxCol);free(X);free(LengthPath);free(Path);return 0; }
  if (DIS<=EPS) DIS=0.0; if (DIS1<=EPS) DIS1=0.0;
  
  S=0.0; i=EdgeNumberPath; if (LengthPath[i]==0.0) i--;
  while (S<=DIS-EPS)
  {
   if (i==0) { S=DIS; break; }  /* checking the limit */ 
   S=S+LengthPath[i];
   i--;
  }
  
  /* Point 2.2 of the algorithm */

  if (fabs(S-DIS)<=EPS) 
  { 
    M=m+2; DIS=S;      
    if (i==0) F=1; 
    else if (i==EdgeNumberPath) F=2;
    else { M--; F=3; }   
  }    
   else {M=m+2; F=0;}
  
  
  if (M==m+2)
  {
  if (F==0) { uv=Path[i+1]; EdgeNumberPath=i+2; LengthPath[i+1]=S-DIS; LengthPath[i+2]=DIS1; 
  Path[i+1]=m+2; Path[i+2]=m+1;}
  else if (F==1) { uv=Path[1]; EdgeNumberPath=2; LengthPath[1]=0.0; LengthPath[2]=DIS1; 
  Path[1]=m+2; Path[2]=m+1;}
  else if (F==2) { uv=Path[EdgeNumberPath]; EdgeNumberPath=EdgeNumberPath+1;LengthPath[EdgeNumberPath]=DIS1; 
  Path[EdgeNumberPath-1]=m+2; Path[EdgeNumberPath]=m+1; } 
  
  for (j=1;j<=n;j++)
     B[m+2][j]=B[uv][j];   
  MaxCol[m+2]=MaxCol[uv];      
  }
 
  else 
  {
     EdgeNumberPath=i+1; LengthPath[i+1]=DIS1; Path[i+1]=m+1;
  }
  
  /* Point 2.3 of the algorithm */

  for (j=1;j<=EdgeNumberPath;j++)
     B[Path[j]][X[k+1]]=1;
     
  /* Point 2.4 of the algorithm */
        
  for (j=1;j<=EdgeNumberPath;j++)
      if (MaxCol[Path[j]]<X[k+1]) MaxCol[Path[j]]=X[k+1];  
      
  /* Point 2.5 of the algorithm */
  
  for (j=PlaceNumber;j>=1;j--) 
      PLACE[j+1]=PLACE[j];
  PLACE[1]=m+1; PlaceNumber++;
  
  if (M==m+2) {
  i=2; 
  while (PLACE[i]!=uv)
         i++;          
  for (j=PlaceNumber;j>=i+1;j--) 
      PLACE[j+1]=PLACE[j];
  PLACE[i+1]=m+2; PlaceNumber++;}
   
  i=M-1; edge=2;
  do 
  {
   if (PLACE[i]==Path[edge]) 
   {
      edge++; j=i+1; 
      while (X[k+1]>MaxCol[PLACE[j]]) 
            j++; 
      if (j>i+1) 
      {            
            l1=PLACE[i];
            for (l=i+1;l<=j-1;l++) 
                 PLACE[l-1]=PLACE[l];              
            PLACE[j-1]=l1;
             
      } 
    }
    i--;
   } while (i!=0); 
   
   m=M;
   }
   

/* memeory liberation */

 free(MaxCol);
 free(X);
 free(LengthPath);
 free(Path);
 
 return m;
 
}

/* Integer function returning the value of the Robinson and Foulds topological distance
   between two trees given their ordered bipartition table B(2n-3,n) and B1(2n-3,n)
   and its rank lists PLACE(2n-3) and  PLACE1(2n-3) */
  

int Table_Comparaison (int **B, int ** B1, int *PLACE, int *PLACE1, int m, int m1)
{
 int RF=0,i,p,p1;
  
 p=1; p1=1;

 while ((p<=m)&&(p1<=m1))
 {
   i=n;
   while ((B[PLACE[p]][i]==B1[PLACE1[p1]][i])&&(i>1))
         i--;
   if (i==1) { RF=RF+1; p++; p1++; }
   else if (B[PLACE[p]][i]>B1[PLACE1[p1]][i]) p1++;
   else p++; 
 
 }
 RF=(m-RF)+(m1-RF);

 return RF;
}










