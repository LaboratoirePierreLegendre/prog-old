README FOR Robinson_Foulds program.

The program Robinson_Foulds is a freeware created by Vladimir Makarenkov. 
This program allows to compute in the optimal time the Robinson and Foulds topological
distance between two or more additive trees given their distance matrices. The program is
based on the optimal Algorithm proposed by Makarenkov and Leclerc (1999, b) for calculation
of this distance.

The implemented Algorithm requires O(n^2) operations to compute the Robinson and Foulds
topological distance between two additive distance matrices of dimensions nxn.


The two example files consist of the following data:

Example1 - 2 distance matrices on the set of 7 objects representing (the first one) a binary
tree and (the second one) a star tree.  
           

Example 2 - 11 distance matrices on the set of 7 objects the first of which is a matrix taken
from Makarenkov and Leclerc (1999, b) and the following ten are the randomly generated
additive distances. 



THE USER'S GUIDE AVAILABLE IS IN ASCII TEXT AND ADOBE ACROBAT (PDF) FORMAT.



REFERENCES



Day W.H.E. 1985. Optimal Algorithms for Comparing Trees with Labelled Leaves, J. of
Classification 2, 7-28.

Makarenkov V., and Leclerc B. 1997. Tree metrics and their circular orders: some uses for the
reconstruction and fitting of phylogenetic trees, 183-208. In Mathematical hierarchies and
Biology (B. Mirkin et al., eds.), DIMACS Series in Discrete Mathematics and Theoretical
Computer Science 37, Amer. Math. Soc., Providence, R.I.

Makarenkov V., and Leclerc B. 1999 (a). The fitting of a tree metric to a given dissimilarity
with the weighted least squares criterion, Journal of Classification, 16, pp.3-26.

Makarenkov V., and Leclerc B. 1999 (b). An optimal way to compare additive trees using
circular orders, accepted for publication in Journal of Computational Biology.

Robinson D.R., and Foulds L.R. 1981. Comparison of phylogenetic trees, Mathematical
Biosciences 53, 131-147.
