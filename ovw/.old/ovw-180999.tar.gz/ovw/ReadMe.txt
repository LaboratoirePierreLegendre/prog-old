README FOR Optimal Variable Weighting Program


The two example files consist of the data taken from:

Example1 (Ultrametric Clustering in output file) - Table 1 of DeSoete, 1986 
         (Data for ultrametric tree Monte Carlo example).
           

Example 2 (Additive Tree Clustering in output file) - Table 2 of of DeSoete, 1986 
         (Data for addtive tree Monte Carlo example).




THE USER'S GUIDE AVAILABLE IS IN WORD 6 FOR MACINTOSH AND WINDOWS FORMAT.



REFERENCES


Polak, E. (1971), "Computational methods in optimization", New York: academic Press,
 p.2.3.

Press W.H., Flannery B.P., Teukolsky S.A. and Vetterling W. T.(1986), 
"Numerical Recipes, The Art of Scientific Computing", Cambridge University Press. 

De Soete, G. (1986), "Optimal variable weighting for ultrametric and additive
 tree clustering", Quality&Quantity, 20, 169-180. 

De Soete, G. (1988), "OVWTRE: A program for optimal variable weighting for
 ultrametric and additive tree fitting", Journal of Classification, 5, 101-104. 

Milligan, G.W. (1989), "A validation study of a variable weighting algorithm
for cluster analysis", Journal of Classification, 6, 53-71. 

