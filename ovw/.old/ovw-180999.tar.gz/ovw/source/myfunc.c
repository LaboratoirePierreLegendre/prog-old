#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "nrutil.h"


extern int n,m;
extern float **Y,**D;
#define EPS 1.0e-10

float Ultrametric (float V[]);
float Additive_Tree(float V[]);
void Derivatives_Ultrametric(float V[], float Deriv[]);
void Derivatives_Additive_Tree(float V[], float Deriv[]);

float Ultrametric (float V[])
/* A float function computing the value of the Ultrametric loss function
defined in
the article by G. De Soete "Optimal variable weighting for ultrametric and
additive tree
clustering" 20: 169-180, Quality&Quantity (1986). The value of this
function is computed
depending on the vector of auxiliary weights V(m-1) and the matrix of
object-variable
measurements Y (a global variable) */
{
 int i,j,k,p;
 float Lu=0.0,Sum=0.0,c=1.0,A,B,C;

 for (i=1; i<=m-1; i++)
      c=c+V[i]*V[i];

 for (i=1; i<=n; i++)
 {
  for (j=i+1; j<=n; j++)
  {
   D[i][j]=((Y[i][m]-Y[j][m])*(Y[i][m]-Y[j][m]))/c;
   for (p=1; p<=m-1; p++)
        D[i][j]=D[i][j]+(V[p]*V[p])*((Y[i][p]-Y[j][p])*(Y[i][p]-Y[j][p]))/c;
   Sum=Sum+D[i][j];
   D[j][i]=D[i][j]=sqrt(D[i][j]);
   }
  }

  for (i=1; i<=n; i++)
  {
   for (j=i+1; j<=n; j++)
   {
    for (k=j+1; k<=n; k++)
    {
     A=D[i][j]; B=D[i][k]; C=D[j][k];
     if ((fabs(B-C)>EPS)&&(A-B<EPS)&&(A-C<EPS))
        Lu=Lu+(B-C)*(B-C);
     else if ((fabs(A-C)>EPS)&&(B-A<EPS)&&(B-C<EPS))
        Lu=Lu+(A-C)*(A-C);
     else if ((fabs(A-B)>EPS)&&(C-A<EPS)&&(C-B<EPS))
        Lu=Lu+(A-B)*(A-B);

     }
    }
   }
   return Lu/Sum;
 }

float Additive_Tree(float V[])
/* A float function computing the value of the Additive tree loss function
defined in
the article by G. De Soete "Optimal variable weighting for ultrametric and
additive tree
clustering" 20: 169-180, Quality&Quantity (1986). The value of this
function is computed
depending on the vector of auxiliary weights V(m-1) and the matrix of
object-variable
measurements Y (a global variable) */
{
 int i,j,k,l,p;
 float La=0.0,Sum=0.0,c=1.0,A,B,C;

 for (i=1; i<=m-1; i++)
      c=c+V[i]*V[i];

 for (i=1; i<=n; i++)
 {
  for (j=i+1; j<=n; j++)
  {
   D[i][j]=((Y[i][m]-Y[j][m])*(Y[i][m]-Y[j][m]))/c;
   for (p=1; p<=m-1; p++)
        D[i][j]=D[i][j]+(V[p]*V[p])*((Y[i][p]-Y[j][p])*(Y[i][p]-Y[j][p]))/c;
   Sum=Sum+D[i][j];
   D[j][i]=D[i][j]=sqrt(D[i][j]);
   }
  }

  for (i=1; i<=n; i++)
  {
   for (j=i+1; j<=n; j++)
   {
    for (k=j+1; k<=n; k++)
    {
     for (l=k+1; l<=n; l++)
     {
      A=D[i][j]+D[k][l]; B=D[i][k]+D[j][l]; C=D[j][k]+D[i][l];
      if ((fabs(B-C)>EPS)&&(A-B<EPS)&&(A-C<EPS))
         La=La+(B-C)*(B-C);
      else if ((fabs(A-C)>EPS)&&(B-A<EPS)&&(B-C<EPS))
         La=La+(A-C)*(A-C);
      else if ((fabs(A-B)>EPS)&&(C-A<EPS)&&(C-B<EPS))
         La=La+(A-B)*(A-B);
      }
     }
    }
   }
   return La/Sum;
 }



void Derivatives_Ultrametric(float V[], float Deriv[])
{
 /* A void function computing the value of the partial first order
derivatives of
the Ultrametric loss function defined in the article by G. De Soete
"Optimal variable
weighting for ultrametric and additive tree clustering" 20: 169-180,
Quality&Quantity (1986).
The vector of the partial derivatives Deriv(m-1) is computed with respect
to the vector
of auxiliary weights V(m-1) */
 int i,j,k,p,q;
 float S,S1=0.0,S2=0.0,Lu=0.0,Sum=0.0,Sum1,Sum2,c=1.0,A,B,C;
 float ***dDv;

/* Compute the distance matrix D */

 for (i=1; i<=m-1; i++)
      c=c+V[i]*V[i];

 for (i=1; i<=n; i++)
 {
  for (j=i+1; j<=n; j++)
  {
   D[i][j]=((Y[i][m]-Y[j][m])*(Y[i][m]-Y[j][m]))/c;
   for (p=1; p<=m-1; p++)
        D[i][j]=D[i][j]+(V[p]*V[p])*((Y[i][p]-Y[j][p])*(Y[i][p]-Y[j][p]))/c;
   D[i][j]=sqrt(D[i][j]);
   }
  }

 dDv=f3tensor(1,n,1,n,1,m-1);

/* Compute the matrix of the partial derivatives dDv of size (n,n,m-1) */

 for (i=1; i<=n; i++)
 {
  for (j=i+1; j<=n; j++)
  {
   for (p=1; p<=m-1; p++)
   {
    S=0.0;
    for (q=1; q<=m-1; q++)
          S=S+V[p]*V[q]*V[q]*(Y[i][q]-Y[j][q])*(Y[i][q]-Y[j][q])/c/c;
    if (D[i][j]==0.0) dDv[i][j][p]=0.0;
    else dDv[i][j][p]=(-S+V[p]*(Y[i][p]-Y[j][p])*(Y[i][p]-Y[j][p])/c-
                  V[p]*(Y[i][m]-Y[j][m])*(Y[i][m]-Y[j][m])/c/c)/D[i][j];
    }
   }
  }
/* Some auxiliary computations */

  for (i=1; i<=n; i++)
  {
   for (j=i+1; j<=n; j++)
   {
    S2=S2+D[i][j]*D[i][j];
    for (k=j+1; k<=n; k++)
    {
     A=D[i][j]; B=D[i][k]; C=D[j][k];
     if ((fabs(B-C)>EPS)&&(A-B<EPS)&&(A-C<EPS))
          S1=S1+(B-C)*(B-C);
     else if ((fabs(A-C)>EPS)&&(B-A<EPS)&&(B-C<EPS))
          S1=S1+(A-C)*(A-C);
     else if ((fabs(A-B)>EPS)&&(C-A<EPS)&&(C-B<EPS))
          S1=S1+(A-B)*(A-B);
     }

    }
  }

/* Compute the vector of partial derivatives dLu/dVp */

 for (p=1; p<=m-1; p++)
 {
  Sum1=Sum2=0.0;
  for (i=1; i<=n; i++)
  {
   for (j=i+1; j<=n; j++)
   {
    Sum2=Sum2+D[i][j]*dDv[i][j][p];
    for (k=j+1; k<=n; k++)
    {
     A=D[i][j]; B=D[i][k]; C=D[j][k];
     if ((fabs(B-C)>EPS)&&(A-B<EPS)&&(A-C<EPS))
         Sum1=Sum1+(B-C)*(dDv[i][k][p]-dDv[j][k][p]);

     else if ((fabs(A-C)>EPS)&&(B-A<EPS)&&(B-C<EPS))
         Sum1=Sum1+(A-C)*(dDv[i][j][p]-dDv[j][k][p]);

     else if ((fabs(A-B)>EPS)&&(C-A<EPS)&&(C-B<EPS))
          Sum1=Sum1+(A-B)*(dDv[i][j][p]-dDv[i][k][p]);
     }
    }
   }
   Deriv[p]=2.0*(Sum1*S2-Sum2*S1)/S2/S2;
   }

   free_f3tensor(dDv,1,n,1,n,1,m-1);
   return;
 }



void Derivatives_Additive_Tree(float V[], float Deriv[])
{
 /* A void function computing the value of the partial first order
derivatives of
the additive tree loss function defined in the article by G. De Soete
"Optimal variable
weighting for ultrametric and additive tree clustering" 20: 169-180,
Quality&Quantity (1986).
The vector of the partial derivatives Deriv(m-1) is computed with respect
to the vector
of auxiliary weights V(m-1) */
 int i,j,k,p,q,l;
 float S,S1=0.0,S2=0.0,Lu=0.0,Sum=0.0,Sum1,Sum2,c=1.0,A,B,C;
 float ***dDv;

/* Compute the distance matrix D */


 for (i=1; i<=m-1; i++)
      c=c+V[i]*V[i];

 for (i=1; i<=n; i++)
 {
  for (j=i+1; j<=n; j++)
  {
   D[i][j]=((Y[i][m]-Y[j][m])*(Y[i][m]-Y[j][m]))/c;
   for (p=1; p<=m-1; p++)
        D[i][j]=D[i][j]+(V[p]*V[p])*((Y[i][p]-Y[j][p])*(Y[i][p]-Y[j][p]))/c;
   D[i][j]=sqrt(D[i][j]);
   }
  }


 dDv=f3tensor(1,n,1,n,1,m-1);

/* Compute the matrix of the partial derivatives dDv of size (n,n,m-1) */

 for (i=1; i<=n; i++)
 {
  for (j=i+1; j<=n; j++)
  {
   for (p=1; p<=m-1; p++)
   {
    S=0.0;
    for (q=1; q<=m-1; q++)
          S=S+V[p]*V[q]*V[q]*(Y[i][q]-Y[j][q])*(Y[i][q]-Y[j][q])/c/c;
     if (D[i][j]==0.0) dDv[i][j][p]=0.0;
     else dDv[i][j][p]=(-S+V[p]*(Y[i][p]-Y[j][p])*(Y[i][p]-Y[j][p])/c-
                  V[p]*(Y[i][m]-Y[j][m])*(Y[i][m]-Y[j][m])/c/c)/D[i][j];
    }
   }
  }

 /* Some auxiliary computations */

  for (i=1; i<=n; i++)
  {
   for (j=i+1; j<=n; j++)
   {
    S2=S2+D[i][j]*D[i][j];
    for (k=j+1; k<=n; k++)
    {
     for (l=k+1; l<=n; l++)
     {
      A=D[i][j]+D[k][l]; B=D[i][k]+D[j][l]; C=D[j][k]+D[i][l];
      if ((fabs(B-C)>EPS)&&(A-B<EPS)&&(A-C<EPS))
          S1=S1+(B-C)*(B-C);
      else if ((fabs(A-C)>EPS)&&(B-A<EPS)&&(B-C<EPS))
          S1=S1+(A-C)*(A-C);
      else if ((fabs(A-B)>EPS)&&(C-A<EPS)&&(C-B<EPS))
          S1=S1+(A-B)*(A-B);
      }
     }

    }
  }

 /* Compute the vector of partial derivatives dLu/dVp */

 for (p=1; p<=m-1; p++)
 {
  Sum1=Sum2=0.0;
  for (i=1; i<=n; i++)
  {
   for (j=i+1; j<=n; j++)
   {
    Sum2=Sum2+D[i][j]*dDv[i][j][p];
    for (k=j+1; k<=n; k++)
    {
     for (l=k+1; l<=n; l++)
     {
      A=D[i][j]+D[k][l]; B=D[i][k]+D[j][l]; C=D[i][l]+D[j][k];
      if ((fabs(B-C)>EPS)&&(A-B<EPS)&&(A-C<EPS))

Sum1=Sum1+(B-C)*(dDv[i][k][p]+dDv[j][l][p]-dDv[i][l][p]-dDv[j][k][p]);

      else if ((fabs(A-C)>EPS)&&(B-A<EPS)&&(B-C<EPS))

Sum1=Sum1+(A-C)*(dDv[i][j][p]+dDv[k][l][p]-dDv[i][l][p]-dDv[j][k][p]);

      else if ((fabs(A-B)>EPS)&&(C-A<EPS)&&(C-B<EPS))
          Sum1=Sum1+(A-B)*(dDv[i][j][p]+dDv[k][l][p]-dDv[i][k][p]-dDv[j][l][p]);                       }     }    }   }    Deriv[p
]=2.0*(Sum1*S2-Sum2*S1)/S2/S2;
   }

   free_f3tensor(dDv,1,n,1,n,1,m-1);
   return;
 }

