/* --------------------------------------------* 
 * Optimal variable weighting for              *
 * ultrametric and additive tree clustering,   *
 * and k-means partitionning                   *
 *                                             *
 * Input data file format:                     *
 * 1. Number of objects n                      *
 * 2. Number of variables m                    *
 * 3. Rectangular matrix Y (nxm) containing    *
 * measurements of n objects on m variables    *
 * 4. (if k-means partitionning is chosen) the *
 * vector of partition numbers for each object *
 *                                             *
 * Output :                                    *
 * 1. Dissimilarity matrix D (nxn)             *
 * 2. Vector of optimal weights W (m)          * 
 * 3. Minimum value of the loss function       *
 * 4. Number of iterations required by the     *
 * the Polak-Ribiere minimization procedure    *
 *                                             *    
 * Vladimir Makarenkov and Pierre Legendre,    *
 * Universite de Montreal, September 1999      *
 * --------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "nrutil.h"


int m,n;
float **Y=NULL, **D=NULL;
int *Groups=NULL, *Number=NULL;

void frprmn(float p[], int n, float ftol, int *iter, float *fret,
float (*func)(float []), void (*dfunc)(float [], float []));
float Ultrametric (float V[]);
float Additive_Tree(float V[]);
void Derivatives_Ultrametric(float V[], float Deriv[]);
void Derivatives_Additive_Tree(float V[], float Deriv[]);

float K_Partition (float V[]);
void Derivatives_K_Partition (float V[], float Deriv[]);


/* The main function */

int main (void)
				
				
{
 int i,j,q,p,k,P=1,iter,iterMin,method=0,Option,Option1,Option2,Flag1,Flag2;
 FILE *data, *Output1;
 char source[25], source1[25];
 float c,ftol=1.0e-5,fret,C=1.0,Func1,F_V, Limit;
 
printf("* --------------------------------------------*\n"); 
printf("* Optimal variable weighting for              *\n");
printf("* ultrametric and additive tree clustering,   *\n");
printf("* and k-means partitionning                   *\n");
printf("*                                             *\n");
printf("* Input data file format:                     *\n");
printf("* 1. Number of objects n                      *\n");
printf("* 2. Number of variables m                    *\n");
printf("* 3. Rectangular matrix Y (nxm) containing    *\n");
printf("* measurements of n objects on m variables    *\n");
printf("* 4. (if k-means partitionning is chosen) the *\n");
printf("* vector of partition numbers for each object *\n");
printf("*                                             *\n"); 
printf("* Output :                                    *\n");
printf("* 1. Dissimilarity matrix D (nxn)             *\n");
printf("* 2. Vector of optimal weights W (m)          *\n"); 
printf("* 3. Minimum value of the loss function       *\n");
printf("* 4. Number of iterations required by the     *\n");
printf("* the Polak-Ribiere minimization procedure    *\n");
printf("*                                             *\n");    
printf("* Vladimir Makarenkov and Pierre Legendre,    *\n");
printf("* Universite de Montreal, September 1999      *\n");
printf("* --------------------------------------------*\n");

 
 
/* Read object-variables matrix Y(n,m) and its size parameters n and m */

do {
printf("\nFind optimal weights for:\n\n");
printf("1. Ultrametric tree clustering\n");
printf("2. Additive tree clustering \n");
printf("3. K-means partitionning\n\n");
scanf("%d",&method);
} while ((method!=1)&&(method!=2)&&(method!=3));


  printf("\n\nEnter the input file name: \n\n");
  scanf("%s", source);    
  if ((data=fopen(source,"r"))==0) { printf("\nFile %s was not found ", source);  	exit(0); } 
  fscanf(data,"%d",&n);
  fscanf(data,"%d",&m);  
  
 /* Memory allocation Y,D,V,W */
  float *V=vector(1,m-1);
  float *W=vector(1,m);
  float *Vopt=vector(1,m-1);
  
  if (method==3) { Groups=ivector(1,n); Number=ivector(1,n); } 
  Y=matrix(1,n,1,m);
  D=matrix(1,n,1,n); 
  
  for (i=1; i<=n; i++)
  {
  	for (j=1; j<=m; j++)
    { 		
  		fscanf(data,"%f",&c);
  		Y[i][j]=c;
  		
    }
    if (method==3) { fscanf(data,"%d",&Groups[i]); }
   }    
  fclose (data);
  printf ("\nNumber of objects n = %d, number of variables m = %d\n",n,m);
  
  
  /* Untroduction of some options */
  
  do {
  printf("\n\nWould you like to save the results in a file ?\n\n");
  printf("1. Yes\n");
  printf("2. No\n\n");
  scanf("%d",&Option1);
  } while ((Option1!=1)&&(Option1!=2));
  
  if (Option1==1) { 
  printf("\nEnter the output file name\n\n");
  scanf("%s", source1);        
  Output1=fopen(source1,"w"); 
  fprintf(Output1,"Output results for the data from the file %s\n",source);
  fprintf(Output1,"\nNumber of objects n = %d, number of variables m = %d\n",n,m);
  }
  

if (Option1==1) { 
  if (method==1) fprintf(Output1,"\nUltrametric tree clustering\n");
  else if (method==2) fprintf(Output1,"\nAdditive tree clustering\n");
  else fprintf(Output1,"\nK-means partitionning\n");
 }


for (i=1; i<=m-1; i++)
    V[i]=1.0;
    
if (method==1) Func1=Ultrametric(V);
else if (method==2) Func1=Additive_Tree(V);
else 
{
  for (i=1; i<=n; i++)
      Number[i]=0;
  
  for (i=1; i<=n; i++)
  {
   if (Number[i]==0)
   {
     k=1;
     for (j=i+1; j<=n; j++)
         if (Groups[i]==Groups[j]) k++; 
            
     if (Number[i]==0) Number[i]=k;
     for (j=i+1; j<=n; j++)
         if (Groups[i]==Groups[j]) Number[j]=k; 
    }      
  } 
  Func1=K_Partition(V);   
}   
float fretMin=Func1;


do {
printf("\n\nSince the initial estimates for optimal weights W may substantially\n"); 
printf("influence the final results, the following 2 options are proposed: \n\n");
if (method!=3) printf("1. All initial estimates are set equal to 1 (G. De Soete's option)\n");
else printf("1. All initial estimates are set equal to 1\n");
printf("2. Restart the optimization procedure p times with different initial estimates and gradually optimize the results\n\n");
scanf("%d",&Option);
} while ((Option!=1)&&(Option!=2));

if (Option==2) {
printf("\n\nHow many trials p ? \n\n");
scanf("%d",&P);
}

if (Option1==1) { 
  if ((Option==1)&&(method!=3)) fprintf(Output1,"\nAll initial estimates are set equal to 1 (G. De Soete's option)\n");
  else if ((Option==1)&&(method==3)) fprintf(Output1,"\nAll initial estimates are set equal to 1\n");
  else fprintf(Output1,"\nOptimization procedure was restarted %d times with different initial estimates and the optimal results were gradually updated \n",P);
 }
 
Limit=0.0;
if ((method==2)&&(m!=1)&&(Option==2)) {
 do {
  printf("\nTo avoid (if possible) a trivial solution when a weight of 1 is assigned to a single variable, would you like to limit the maximum weight of any one variable?\n\n");
  printf("1. Yes\n");
  printf("2. No\n\n");
  scanf("%d",&Option2);
  } while ((Option2!=1)&&(Option2!=2));
  
if (Option2==1)
do {
  printf("\nType the maximum limit value allowed for the weight of any one single variable (must be between 0 and 1, e.g. 0.95, 0.9, 0.8 ...)\n\n");  
  scanf("%f",&Limit);
  } while ((Limit<=0)||(Limit>=1));
  
  if ((Option2==1)&&(Option1==1)) fprintf(Output1,"\n\nThe maximum limit value allowed for the weight of any one single variable is %f\n",Limit);  
 } 
   

printf("\n\nComputation begins ... \n\n");

/* Call the function being minimized */
Flag2=0;
for (i=1;i<=P;i++) 
{
 if (Option==2) printf("\nTrial number %d of %d \n",i,P);
 if (i>1)
 {
  for (j=1;j<=m-1;j++) 
       { V[j]=20.0*rand()/RAND_MAX;}
        
 }       
  
 if (method==1)
 {   frprmn(V,m-1,ftol,&iter,&fret, Ultrametric, Derivatives_Ultrametric);
     F_V=Ultrametric(V); }
 else if (method==2)
 {   frprmn(V,m-1,ftol,&iter,&fret, Additive_Tree, Derivatives_Additive_Tree);
     F_V=Additive_Tree(V); }       
 else  
 {   frprmn(V,m-1,ftol,&iter,&fret, K_Partition, Derivatives_K_Partition);
     F_V=K_Partition(V); }    
          
/* Try to avoid a trivial solution when an additive tree clustering is performed */  
 Flag1=0;
 C=0.0;
 for (q=1; q<=m-1; q++)
     C=C+V[q]*V[q];
 for (p=1; p<=m-1; p++)     
     W[p]=(V[p]*V[p])/C;
 W[m]=1.0/C;
 for (q=1;q<=m;q++) 
    if (W[q]>=Limit) Flag1=1;    
     
  
  if (((i==1)||((F_V<fretMin)&&(Flag1==0)))||((i>1)&&(Flag2==1)&&(Flag1==0)))
  {
    if ((i==1)&&(Flag1==1)) Flag2=1;
    else if ((i>1)&&(Flag2==1)) Flag2=0;
    
    fretMin=F_V;
    iterMin=iter;
    for (j=1;j<=m-1;j++) 
        Vopt[j]=V[j];
  }   
     
 }   

if (method==1)  
     F_V=Ultrametric(Vopt); 
 else if (method==2)
     F_V=Additive_Tree(Vopt);
 else 
     F_V=K_Partition(Vopt);    

/* Compute the optimal weights W from the auxiliary optimal weights V */

C=0.0;
for (q=1; q<=m-1; q++)
     C=C+Vopt[q]*Vopt[q];
for (p=1; p<=m-1; p++)     
     W[p]=(Vopt[p]*Vopt[p])/C;
W[m]=1.0/C;

if (Option1==1) printf("\n\nResults are in the output file %s",source1);

/* Print the results in the file or on the screen*/

if (Option1==1) { 
   fprintf(Output1,"\n\nRESULTS:");
   fprintf(Output1,"\n\nDissimilarity matrix D inferred from the input data matrix using optimal weights\n\n");
 }
else { 
printf("\n\nRESULTS:");
printf("\n\nDissimilarity matrix D inferred from the input data matrix using optimal weights\n\n");
}
if (Option1==1) { 
    for (i=1; i<=n; i++)
    {
       D[i][i]=0.0;
       for (j=1; j<=n; j++)
            fprintf(Output1,"%f ",D[i][j]);   	
       fprintf(Output1,"\n");  
    } 
    fprintf(Output1,"\n\nVector of optimal weights W found for the variables\n\n");
    for (i=1; i<=m; i++)
         fprintf(Output1,"%f ",W[i]);

    fprintf(Output1,"\n\n\nThe minimum value of the function being minimized dropped from %f (when all weights were equal to 1) to %f (for the optimal weights)\n\n",Func1,fretMin); 
    fprintf(Output1,"\nTotal number of iterations in the Polak-Ribiere minimization procedure giving optimal weights: %d\n\n",iterMin);
    fclose (Output1);
}
else {
      for (i=1; i<=n; i++)
      {
        D[i][i]=0.0;
        for (j=1; j<=n; j++)
            printf("%f ",D[i][j]);   	
        printf("\n");  
       } 
       printf("\n\nVector of optimal weights W found for the variables\n\n");
       for (i=1; i<=m; i++)
           printf("%f ",W[i]);

       printf("\n\n\nThe minimum value of the function being minimized dropped from %f (when all weights were equal to 1) to %f (for the optimal weights)\n\n",Func1,fretMin); 
       printf("\nTotal number of iterations in the Polak-Ribiere minimization procedure giving optimal weights: %d\n\n",iterMin);
      } 
}


