#include <stdio.h>
#include "nrutil.h"

void linmin(float p[], float xi[], int n, float *fret, float (*func)(float []));

float Ultrametric(float *);
void Derivatives_Ultrametric(float *, float *);
float Additive_Tree(float *);
void Derivatives_Additive_Tree(float *, float *);


#define TOL 2.0e-4 /*Tolerance passed to brent.*/
int ncom; /*Global variables communicate with f1dim.*/
float *pcom,*xicom,(*nrfunc)(float []);
void linmin(float p[], float xi[], int n, float *fret, float (*func)(float []))
/*Given an n-dimensional point p[1..n] and an n-dimensional direction xi[1..n], moves and
resets p to where the function func(p) takes on a minimum along the direction xi from p,
and replaces xi by the actual vector displacement that p was moved. Also returns as fret
the value of func at the returned location p. This is actually all accomplished by calling the
routines mnbrak and brent.*/
{
float brent(float ax, float bx, float cx,
float (*f)(float), float tol, float *xmin);
float f1dim(float x);
void mnbrak(float *ax, float *bx, float *cx, float *fa, float *fb,
float *fc, float (*func)(float));
int j;
float xx,xmin,fx,fb,fa,bx,ax;
ncom=n; /*Dene the global variables.*/
pcom=vector(1,n);
xicom=vector(1,n);
nrfunc=func;
for (j=1;j<=n;j++) {
pcom[j]=p[j];
xicom[j]=xi[j];
}
ax=0.0; /*Initial guess for brackets.*/
xx=1.0;
mnbrak(&ax,&xx,&bx,&fa,&fx,&fb,f1dim);
*fret=brent(ax,xx,bx,f1dim,TOL,&xmin);
for (j=1;j<=n;j++) 
{ /*Construct the vector results to return.*/
xi[j] *= xmin;
p[j] += xi[j];
}
free_vector(xicom,1,n);
free_vector(pcom,1,n);
}
