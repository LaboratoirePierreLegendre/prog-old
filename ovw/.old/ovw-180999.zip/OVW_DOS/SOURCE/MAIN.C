/* 
* ------------------------------------------------------------------------------- *
* Optimal variable weighting for ultrametric and additive tree clustering         *
* (Geert De Soete's method)                                                       *
*                                                                                 *
* Input data file format:                                                         *
*                                                                                 *
* Number of objects n                                                             *
* Number of variables m                                                           *
* Rectangular matrix Y (nxm) containing measurements of n objects on m variables  *
*                                                                                 *
* Output data:                                                                    *
*                                                                                 *
* Dissimilarity matrix D (nxn) obtained using optimal weights                     *
* Vector of optimal weights W (m)                                                 *
* Minimum value of the function being minimized                                   *
* Number of iterations in the minimization procedure being made                   *
*                                                                                 *
* Vladimir Makarenkov and Pierre Legendre, University of Montreal, September 1999 *
* ------------------------------------------------------------------------------- *
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/*#include <time.h>*/
/*#include "Types.h"*/

#include "nrutil.h"
/*#include "nr.h"*/

int m,n;
float **Y=NULL, **D=NULL;

void frprmn(float p[], int n, float ftol, int *iter, float *fret,
float (*func)(float []), void (*dfunc)(float [], float []));
float Ultrametric (float V[]);
float Additive_Tree(float V[]);
void Derivatives_Ultrametric(float V[], float Deriv[]);
void Derivatives_Additive_Tree(float V[], float Deriv[]);


/* The main function */

int main (void)
				
				
{
 int i,j,q,p,P=1,iter,iterMin,method=0,Option,Option1;
 FILE *data, *Output1;
 char source[25], source1[25];
 float c,ftol=1.0e-5,fret,C=1.0,Func1,F_V;
 
printf("* --------------------------------------------*\n"); 
printf("* Optimal variable weighting for              *\n");
printf("* ultrametric and additive tree clustering    *\n");
printf("* (Geert De Soete's method)                   *\n");
printf("*                                             *\n");
printf("* Input data file format:                     *\n");
printf("* 1. Number of objects n                      *\n");
printf("* 2. Number of variables m                    *\n");
printf("* 3. Rectangular matrix Y (nxm) containing    *\n");
printf("*    measurements of n objects on m variables *\n");
printf("*                                             *\n"); 
printf("* Output data:                                *\n");
printf("* 1. Dissimilarity matrix D (nxn) obtained    *\n");
printf("* 2. Vector of optimal weights W (m)          *\n"); 
printf("* 3. Minimum value of the loss function       *\n");
printf("* 4. Number of iterations in                  *\n");
printf("*    the minimization procedure being made    *\n");
printf("*                                             *\n");    
printf("* Vladimir Makarenkov and Pierre Legendre,    *\n");
printf("* University of Montreal, September 1999      *\n");
printf("* --------------------------------------------*\n");

 
 
/* Read object-variables matrix Y(n,m) and its size parameters n and m */

  printf("\nEnter the input file name: \n\n");
  scanf("%s", source);
    
  if ((data=fopen(source,"r"))==0) { printf("\nFile %s was not found ", source);  	exit(0); } 
  fscanf(data,"%d",&n);
  fscanf(data,"%d",&m);  
  
 /* Memory allocation Y,D,V,W */
  float *V=vector(1,m-1);
  float *W=vector(1,m);
  float *Vopt=vector(1,m-1);  
  Y=matrix(1,n,1,m);
  D=matrix(1,n,1,n); 
  
  for (i=1; i<=n; i++)
  {
  	for (j=1; j<=m; j++)
    { 		
  		fscanf(data,"%f",&c);
  		Y[i][j]=c;
  		
    }
   }    
  fclose (data);
  printf ("\nNumber of objects n = %d, number of variables m = %d\n",n,m);
  
  do {
  printf("\n\nWould you like to save the results in a file? \n\n");
  printf("1. Yes\n");
  printf("2. No\n\n");
  scanf("%d",&Option1);
  } while ((Option1!=1)&&(Option1!=2));
  
  if (Option1==1) { 
  printf("\nEnter the output file name\n\n");
  scanf("%s", source1);        
  Output1=fopen(source1,"w"); 
  fprintf(Output1,"Output results for the data from the file %s\n",source);
  fprintf(Output1,"\nNumber of objects n = %d, number of variables m = %d\n",n,m);
  }
  
/* Untroduction of some options */

do {
printf("\n\nWhat kind of analysis would you like to perform? \n\n");
printf("1. Ultrametric tree clustering\n");
printf("2. Additive tree clustering \n\n");
scanf("%d",&method);
} while ((method!=1)&&(method!=2));

if (Option1==1) { 
  if (method==1) fprintf(Output1,"\nUltrametric tree clustering\n");
  else fprintf(Output1,"\nAdditive tree clustering\n");
 }


for (i=1; i<=m-1; i++)
    V[i]=1.0;
if (method==1) Func1=Ultrametric(V);
else Func1=Additive_Tree(V);
float fretMin=Func1;


do {
printf("\n\nAs the values of initial estimates for optimal weights W might substantially\n"); 
printf("influence the final results the following 2 options are proposed: \n\n");
printf("1. All initial estimates are set equal to 1 (G. De Soete's option)\n");
printf("2. Restart the optimization procedure p times with different initial estimates and gradually update the optimal result\n\n");
scanf("%d",&Option);
} while ((Option!=1)&&(Option!=2));

if (Option==2) {
printf("\n\nEnter number of trials p \n\n");
scanf("%d",&P);
}

if (Option1==1) { 
  if (Option==1) fprintf(Output1,"\nAll initial estimates are set equal to 1 (G. De Soete's option)\n");
  else fprintf(Output1,"\nOptimization procedure was restarted %d times with different initial estimates and the optimal results were gradually updated \n",P);
 }

printf("\n\nComputation begins \n\n");

/* Call the function being minimized */

for (i=1;i<=P;i++) 
{
 if (Option==2) printf("\nTrial number %d of %d \n",i,P);
 if (i>1)
 {
  /*srand(i);*/
  for (j=1;j<=m-1;j++) 
       { V[j]=20.0*rand()/RAND_MAX;
        /*printf("%f ",V[j]);*/}
        
 }       
 
 if (method==1)
 {   frprmn(V,m-1,ftol,&iter,&fret, Ultrametric, Derivatives_Ultrametric);
     F_V=Ultrametric(V); }
 else 
 {   frprmn(V,m-1,ftol,&iter,&fret, Additive_Tree, Derivatives_Additive_Tree);
     F_V=Additive_Tree(V); } 
  
  if ((i==1)||(F_V<fretMin))
  {
    fretMin=F_V;
    iterMin=iter;
    for (j=1;j<=m-1;j++) 
        Vopt[j]=V[j];
  }   
     
 }   

if (method==1)  
     F_V=Ultrametric(Vopt); 
 else 
     F_V=Additive_Tree(Vopt); 

/* Compute the optimal weights W from the auxiliary optimal weights V */

for (q=1; q<=m-1; q++)
     C=C+Vopt[q]*Vopt[q];
for (p=1; p<=m-1; p++)     
     W[p]=(Vopt[p]*Vopt[p])/C;
W[m]=1.0/C;

if (Option1==1) printf("\n\nResults are in the output file %s",source1);
/* Print the results */

if (Option1==1) { 
   fprintf(Output1,"\n\nRESULTS OBTAINED:");
   fprintf(Output1,"\n\nDissimilarity matrix D inferred from your objects-variables matrix using optimal weights\n\n");
 }
else { 
printf("\n\nRESULTS OBTAINED:");
printf("\n\nDissimilarity matrix D inferred from your objects-variables matrix using optimal weights\n\n");
}
if (Option1==1) { 
    for (i=1; i<=n; i++)
    {
       D[i][i]=0.0;
       for (j=1; j<=n; j++)
            fprintf(Output1,"%f ",D[i][j]);   	
       fprintf(Output1,"\n");  
    } 
    fprintf(Output1,"\n\nVector of optimal weights W found for each of variables from your objects-variables matrix\n\n");
    for (i=1; i<=m; i++)
         fprintf(Output1,"%f ",W[i]);

    fprintf(Output1,"\n\n\nThe minimum value of the function being minimize dropped from %f (while all the weights are equal to 1) to %f (for the obtained optimal weights)\n\n",Func1,fretMin); 
    fprintf(Output1,"\nNumber of iterations in the Polak-Ribiere minimization procedure: %d\n\n",iterMin);
    fclose (Output1);
}
else {
      for (i=1; i<=n; i++)
      {
        D[i][i]=0.0;
        for (j=1; j<=n; j++)
            printf("%f ",D[i][j]);   	
        printf("\n");  
       } 
       printf("\n\nVector of optimal weights W found for each of variables from your objects-variables matrix\n\n");
       for (i=1; i<=m; i++)
           printf("%f ",W[i]);

       printf("\n\n\nThe minimum value of the function being minimize dropped from %f (while all the weights are equal to 1) to %f (for the obtained optimal weights)\n\n",Func1,fretMin); 
       printf("\nNumber of iterations in the Polak-Ribiere minimization procedure: %d\n\n",iterMin);
      } 
}


