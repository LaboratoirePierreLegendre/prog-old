#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "nrutil.h"


extern int n,m;
extern float **Y,**D;
extern int *Groups,*Number;
#define EPS 1.0e-10

float Ultrametric (float V[]);
float Additive_Tree(float V[]);
void Derivatives_Ultrametric(float V[], float Deriv[]);
void Derivatives_Additive_Tree(float V[], float Deriv[]);

float K_Partition (float V[]);
void Derivatives_K_Partition (float V[], float Deriv[]);


float Ultrametric (float V[])
/* A float function computing the value of the Ultrametric loss function defined in
the article by G. De Soete "Optimal variable weighting for ultrametric and additive tree
clustering" 20: 169-180, Quality&Quantity (1986). The value of this function is computed
depending on the vector of auxiliary weights V(m-1) and the matrix of object-variable
measurements Y (a global variable) */
{
 int i,j,k,p;
 float Lu=0.0,Sum=0.0,c=1.0,A,B,C;
 
 for (i=1; i<=m-1; i++)
      c=c+V[i]*V[i];
 
 for (i=1; i<=n; i++)
 {
  for (j=i+1; j<=n; j++) 
  {
   D[i][j]=((Y[i][m]-Y[j][m])*(Y[i][m]-Y[j][m]))/c;
   for (p=1; p<=m-1; p++) 
        D[i][j]=D[i][j]+(V[p]*V[p])*((Y[i][p]-Y[j][p])*(Y[i][p]-Y[j][p]))/c;
   Sum=Sum+D[i][j];
   D[j][i]=D[i][j]=sqrt(D[i][j]);
   }
  }
  
  for (i=1; i<=n; i++)
  {
   for (j=i+1; j<=n; j++) 
   {
    for (k=j+1; k<=n; k++) 
    {
     A=D[i][j]; B=D[i][k]; C=D[j][k];
     if ((fabs(B-C)>EPS)&&(A-B<EPS)&&(A-C<EPS))
        Lu=Lu+(B-C)*(B-C);
     else if ((fabs(A-C)>EPS)&&(B-A<EPS)&&(B-C<EPS))
        Lu=Lu+(A-C)*(A-C);
     else if ((fabs(A-B)>EPS)&&(C-A<EPS)&&(C-B<EPS))
        Lu=Lu+(A-B)*(A-B);
        
     }
    }
   }
   Lu=Lu/Sum; if (fabs(Lu)<=0.000000000001) Lu=0.0;
   return Lu;
 } 

float Additive_Tree(float V[])
/* A float function computing the value of the Additive tree loss function defined in
the article by G. De Soete "Optimal variable weighting for ultrametric and additive tree
clustering" 20: 169-180, Quality&Quantity (1986). The value of this function is computed
depending on the vector of auxiliary weights V(m-1) and the matrix of object-variable
measurements Y (a global variable) */
{
 int i,j,k,l,p;
 float La=0.0,Sum=0.0,c=1.0,A,B,C;
 
 for (i=1; i<=m-1; i++)
      c=c+V[i]*V[i];
 
 for (i=1; i<=n; i++)
 {
  for (j=i+1; j<=n; j++) 
  {
   D[i][j]=((Y[i][m]-Y[j][m])*(Y[i][m]-Y[j][m]))/c;
   for (p=1; p<=m-1; p++) 
        D[i][j]=D[i][j]+(V[p]*V[p])*((Y[i][p]-Y[j][p])*(Y[i][p]-Y[j][p]))/c;
   Sum=Sum+D[i][j];
   D[j][i]=D[i][j]=sqrt(D[i][j]);
   }
  }
  
  for (i=1; i<=n; i++)
  {
   for (j=i+1; j<=n; j++) 
   {
    for (k=j+1; k<=n; k++) 
    {
     for (l=k+1; l<=n; l++) 
     {    
      A=D[i][j]+D[k][l]; B=D[i][k]+D[j][l]; C=D[j][k]+D[i][l];
      if ((fabs(B-C)>EPS)&&(A-B<EPS)&&(A-C<EPS))
         La=La+(B-C)*(B-C);
      else if ((fabs(A-C)>EPS)&&(B-A<EPS)&&(B-C<EPS))
         La=La+(A-C)*(A-C);
      else if ((fabs(A-B)>EPS)&&(C-A<EPS)&&(C-B<EPS))
         La=La+(A-B)*(A-B);        
      }
     }
    }
   }
   
   La=La/Sum; if (fabs(La)<=0.000000000001) La=0.0;
   return La;
 } 

float K_Partition (float V[])
/* A float function computing the value of the K-means loss function. The value of this function is computed
depending on the vector of auxiliary weights V(m-1) and the matrix of object-variable
measurements Y (a global variable) */
{
 int i,j,p;
 float Lg=0.0;
 double Sum=0.0,c=1.0;
 
 for (i=1; i<=m-1; i++)
      c=c+V[i]*V[i];
 
 for (i=1; i<=n; i++)
 {
  for (j=i+1; j<=n; j++) 
  {
   D[i][j]=((Y[i][m]-Y[j][m])*(Y[i][m]-Y[j][m]))/c;
   for (p=1; p<=m-1; p++) 
        D[i][j]=D[i][j]+(V[p]*V[p])*((Y[i][p]-Y[j][p])*(Y[i][p]-Y[j][p]))/c;
   Sum=Sum+D[i][j];
   D[j][i]=D[i][j]=sqrt(D[i][j]);
   }
  }
  
  for (i=1; i<=n; i++)
  {
   for (j=i+1; j<=n; j++) 
       if (Groups[i]==Groups[j]) Lg=Lg+D[i][j]*D[i][j]/Number[i];
  }
 
  if (fabs(Lg)<=0.000000000001) Lg=0.0;
  
   return Lg;
 } 


void Derivatives_Ultrametric(float V[], float Deriv[])
{
 /* A void function computing the value of the partial first order derivatives of
the Ultrametric loss function defined in the article by G. De Soete "Optimal variable
weighting for ultrametric and additive tree clustering" 20: 169-180, Quality&Quantity (1986).
The vector of the partial derivatives Deriv(m-1) is computed with respect to the vector
of auxiliary weights V(m-1) */
 int i,j,k,p,q,k1,k2,k3;
 float S,S1=0.0,S2=0.0,Lu=0.0,Sum=0.0,Sum1,Sum2,c=1.0,A,B,C;
 float **dDv;
 
/* Compute the distance matrix D */ 
 
 for (i=1; i<=m-1; i++)
      c=c+V[i]*V[i];
 
 for (i=1; i<=n; i++)
 {
  for (j=i+1; j<=n; j++) 
  {
   D[i][j]=((Y[i][m]-Y[j][m])*(Y[i][m]-Y[j][m]))/c;
   for (p=1; p<=m-1; p++) 
        D[i][j]=D[i][j]+(V[p]*V[p])*((Y[i][p]-Y[j][p])*(Y[i][p]-Y[j][p]))/c;
   D[i][j]=sqrt(D[i][j]);
   }
  }

 dDv=matrix(1,n*(n-1)/2,1,m-1); 
 
/* Compute the matrix of the partial derivatives dDv of size (n,n,m-1) */  
 
 for (i=1; i<=n; i++)
 {
  for (j=i+1; j<=n; j++) 
  {
   k=n*(i-1)-i*(i-1)/2+j-i;
   for (p=1; p<=m-1; p++) 
   {
    S=0.0;
    for (q=1; q<=m-1; q++) 
          S=S+V[p]*V[q]*V[q]*(Y[i][q]-Y[j][q])*(Y[i][q]-Y[j][q])/c/c;
    if (D[i][j]==0.0) dDv[k][p]=0.0;         
    else dDv[k][p]=(-S+V[p]*(Y[i][p]-Y[j][p])*(Y[i][p]-Y[j][p])/c-
                  V[p]*(Y[i][m]-Y[j][m])*(Y[i][m]-Y[j][m])/c/c)/D[i][j];
    }
   } 
  }
/* Some auxiliary computations */  
  
  for (i=1; i<=n; i++)
  {
   for (j=i+1; j<=n; j++) 
   {
    S2=S2+D[i][j]*D[i][j];
    for (k=j+1; k<=n; k++) 
    {
     A=D[i][j]; B=D[i][k]; C=D[j][k];
     if ((fabs(B-C)>EPS)&&(A-B<EPS)&&(A-C<EPS))
          S1=S1+(B-C)*(B-C);     
     else if ((fabs(A-C)>EPS)&&(B-A<EPS)&&(B-C<EPS))              
          S1=S1+(A-C)*(A-C);     
     else if ((fabs(A-B)>EPS)&&(C-A<EPS)&&(C-B<EPS))
          S1=S1+(A-B)*(A-B);            
     }
        
    } 
  }

/* Compute the vector of partial derivatives dLu/dVp */ 
  
 for (p=1; p<=m-1; p++) 
 {
  Sum1=Sum2=0.0;  
  for (i=1; i<=n; i++)
  {
   for (j=i+1; j<=n; j++) 
   {
    k1=n*(i-1)-i*(i-1)/2+j-i;
    Sum2=Sum2-D[i][j]*dDv[k1][p];
    for (k=j+1; k<=n; k++) 
    {     
     A=D[i][j]; B=D[i][k]; C=D[j][k];
     k2=n*(i-1)-i*(i-1)/2+k-i; k3=n*(j-1)-j*(j-1)/2+k-j;
     if ((fabs(B-C)>EPS)&&(A-B<EPS)&&(A-C<EPS))
         Sum1=Sum1+(B-C)*(dDv[k2][p]-dDv[k3][p]);   
     
     else if ((fabs(A-C)>EPS)&&(B-A<EPS)&&(B-C<EPS))       
         Sum1=Sum1+(A-C)*(dDv[k1][p]-dDv[k3][p]);
     
     else if ((fabs(A-B)>EPS)&&(C-A<EPS)&&(C-B<EPS))
          Sum1=Sum1+(A-B)*(dDv[k1][p]-dDv[k2][p]);                 
     }
    }
   }
   Deriv[p]=2.0*(Sum1*S2-Sum2*S1)/S2/S2;
   }
   
   free_matrix(dDv,1,n*(n-1)/2,1,m-1);
   return;
 } 



void Derivatives_Additive_Tree(float V[], float Deriv[])
{
 /* A void function computing the value of the partial first order derivatives of
the additive tree loss function defined in the article by G. De Soete "Optimal variable
weighting for ultrametric and additive tree clustering" 20: 169-180, Quality&Quantity (1986).
The vector of the partial derivatives Deriv(m-1) is computed with respect to the vector
of auxiliary weights V(m-1) */
 int i,j,k,p,q,l,k1,k2,k3,k4,k5,k6;
 float S,S1=0.0,S2=0.0,Lu=0.0,Sum=0.0,Sum1,Sum2,c=1.0,A,B,C;
 float **dDv;
 
/* Compute the distance matrix D */ 
 
 
 for (i=1; i<=m-1; i++)
      c=c+V[i]*V[i];
 
 for (i=1; i<=n; i++)
 {
  for (j=i+1; j<=n; j++) 
  {
   D[i][j]=((Y[i][m]-Y[j][m])*(Y[i][m]-Y[j][m]))/c;
   for (p=1; p<=m-1; p++) 
        D[i][j]=D[i][j]+(V[p]*V[p])*((Y[i][p]-Y[j][p])*(Y[i][p]-Y[j][p]))/c;
   D[i][j]=sqrt(D[i][j]);
   }
  }
  

 dDv=matrix(1,n*(n-1)/2,1,m-1); 
 
/* Compute the matrix of the partial derivatives dDv of size (n,n,m-1) */  
 
 for (i=1; i<=n; i++)
 {
  for (j=i+1; j<=n; j++) 
  {
   k=n*(i-1)-i*(i-1)/2+j-i;
   for (p=1; p<=m-1; p++) 
   {
    S=0.0;
    for (q=1; q<=m-1; q++) 
          S=S+V[p]*V[q]*V[q]*(Y[i][q]-Y[j][q])*(Y[i][q]-Y[j][q])/c/c;
     if (D[i][j]==0.0) dDv[k][p]=0.0;   
     else dDv[k][p]=(-S+V[p]*(Y[i][p]-Y[j][p])*(Y[i][p]-Y[j][p])/c-
                  V[p]*(Y[i][m]-Y[j][m])*(Y[i][m]-Y[j][m])/c/c)/D[i][j];
    }
   } 
  }
  
 /* Some auxiliary computations */  
  
  for (i=1; i<=n; i++)
  {
   for (j=i+1; j<=n; j++) 
   {
    S2=S2+D[i][j]*D[i][j];
    for (k=j+1; k<=n; k++) 
    {
     for (l=k+1; l<=n; l++) 
     {         
      A=D[i][j]+D[k][l]; B=D[i][k]+D[j][l]; C=D[j][k]+D[i][l];
      if ((fabs(B-C)>EPS)&&(A-B<EPS)&&(A-C<EPS))        
          S1=S1+(B-C)*(B-C);        
      else if ((fabs(A-C)>EPS)&&(B-A<EPS)&&(B-C<EPS))              
          S1=S1+(A-C)*(A-C);      
      else if ((fabs(A-B)>EPS)&&(C-A<EPS)&&(C-B<EPS))
          S1=S1+(A-B)*(A-B);             
      }
     }
        
    } 
  }
 
 /* Compute the vector of partial derivatives dLu/dVp */  
  
 for (p=1; p<=m-1; p++) 
 {
  Sum1=Sum2=0.0;  
  for (i=1; i<=n; i++)
  {
   for (j=i+1; j<=n; j++) 
   {
    k1=n*(i-1)-i*(i-1)/2+j-i;
    Sum2=Sum2+D[i][j]*dDv[k][p];    
    for (k=j+1; k<=n; k++) 
    {
     k2=n*(i-1)-i*(i-1)/2+k-i; k3=n*(j-1)-j*(j-1)/2+k-j;
     for (l=k+1; l<=n; l++) 
     {   
      k4=n*(i-1)-i*(i-1)/2+l-i; k5=n*(j-1)-j*(j-1)/2+l-j; k6=n*(k-1)-k*(k-1)/2+l-k;
      A=D[i][j]+D[k][l]; B=D[i][k]+D[j][l]; C=D[i][l]+D[j][k];
      if ((fabs(B-C)>EPS)&&(A-B<EPS)&&(A-C<EPS))
          Sum1=Sum1+(B-C)*(dDv[k2][p]+dDv[k5][p]-dDv[k4][p]-dDv[k3][p]);               
      else if ((fabs(A-C)>EPS)&&(B-A<EPS)&&(B-C<EPS))       
          Sum1=Sum1+(A-C)*(dDv[k1][p]+dDv[k6][p]-dDv[k4][p]-dDv[k3][p]);           
      else if ((fabs(A-B)>EPS)&&(C-A<EPS)&&(C-B<EPS))
          Sum1=Sum1+(A-B)*(dDv[k1][p]+dDv[k6][p]-dDv[k2][p]-dDv[k5][p]);                 
      }
     }
    }
   }
    Deriv[p]=2.0*(Sum1*S2-Sum2*S1)/S2/S2;
   }
   
   free_matrix(dDv,1,n*(n-1)/2,1,m-1);
   return;
 } 


void Derivatives_K_Partition (float V[], float Deriv[])
/* A float function computing the value of the K-means loss function. The value of this function is computed
depending on the vector of auxiliary weights V(m-1) and the matrix of object-variable
measurements Y (a global variable) */
{
 int i,j,p,q,k;
 float **dDv;
 double S,Sum=0.0,c=1.0;
 
 
 for (i=1; i<=m-1; i++)
      c=c+V[i]*V[i];
 
 for (i=1; i<=n; i++)
 {
  for (j=i+1; j<=n; j++) 
  {
   D[i][j]=((Y[i][m]-Y[j][m])*(Y[i][m]-Y[j][m]))/c;
   for (p=1; p<=m-1; p++) 
        D[i][j]=D[i][j]+(V[p]*V[p])*((Y[i][p]-Y[j][p])*(Y[i][p]-Y[j][p]))/c;
   Sum=Sum+D[i][j];
   D[j][i]=D[i][j]=sqrt(D[i][j]);
   }
  }
  
  
 dDv=matrix(1,n*(n-1)/2,1,m-1); 
 
/* Compute the matrix of the partial derivatives dDv of size (n,n,m-1) */  
 
 for (i=1; i<=n; i++)
 {
  for (j=i+1; j<=n; j++) 
  {
   k=n*(i-1)-i*(i-1)/2+j-i;
   for (p=1; p<=m-1; p++) 
   {
    S=0.0;
    for (q=1; q<=m-1; q++) 
          S=S+V[p]*V[q]*V[q]*(Y[i][q]-Y[j][q])*(Y[i][q]-Y[j][q])/c/c;
    if (fabs(D[i][j])<=0.00000000001) dDv[k][p]=0.0;         
    else dDv[k][p]=(-S+V[p]*(Y[i][p]-Y[j][p])*(Y[i][p]-Y[j][p])/c-
                  V[p]*(Y[i][m]-Y[j][m])*(Y[i][m]-Y[j][m])/c/c)/D[i][j];
    }
   } 
  }

  
/* Compute the vector of partial derivatives dLg/dVp */ 

 for (p=1; p<=m-1; p++) 
 {
  Deriv[p]=0.0;
  for (i=1; i<=n; i++)
  {
   for (j=i+1; j<=n; j++)
   {     
       k=n*(i-1)-i*(i-1)/2+j-i;
       if (Groups[i]==Groups[j]) Deriv[p]=Deriv[p]+2.0*D[i][j]*dDv[k][p]/Number[i];
   }   
  }
 }
  
   free_matrix(dDv,1,n*(n-1)/2,1,m-1);
   return;   
 } 
