#include "nrutil.h"


float Ultrametric(float *);
void Derivatives_Ultrametric(float *, float *);
float Additive_Tree(float *);
void Derivatives_Additive_Tree(float *, float *);

float f1dim(float x);

/*float f1dim(float x);*/

extern int ncom; /*Defined in linmin.*/
extern float *pcom,*xicom,(*nrfunc)(float []);
float f1dim(float x)
/*Must accompany linmin.*/
{
int j;
float f,*xt;
xt=vector(1,ncom);
for (j=1;j<=ncom;j++) xt[j]=pcom[j]+x*xicom[j];
f=(*nrfunc)(xt);
free_vector(xt,1,ncom);
return f;
}
