README for Optimal Variable Weighting Program


The three examples consist of the data taken from:

Examples 1 and 3 (Ultrametric Clustering and K-Means Partitioning) - Table 1 from De Soete (1986).

Example 2 (Additive Tree Reconstruction) - Table 2 from De Soete (1986),.


THE USER'S GUIDE AVAILABLE IS IN ADOBE ACROBAT (PDF) FORMAT.


REFERENCES


Polak, E. (1971), "Computational methods in optimization", New York: academic Press,
 p.2.3.

Press W.H., Flannery B.P., Teukolsky S.A. and Vetterling W. T.(1986), 
"Numerical Recipes, The Art of Scientific Computing", Cambridge University Press. 

De Soete, G. (1986), "Optimal variable weighting for ultrametric and additive
 tree clustering", Quality&Quantity, 20, 169-180. 

De Soete, G. (1988), "OVWTRE: A program for optimal variable weighting for
 ultrametric and additive tree fitting", Journal of Classification, 5, 101-104. 

Milligan, G.W. (1989), "A validation study of a variable weighting algorithm
for cluster analysis", Journal of Classification, 6, 53-71.

Makarenkov, V. and Legendre P. (2001), "Optimal variable weighting for
ultrametric and additive trees and K-means partitioning: methods and
software",  to appear in Journal of Classification, 18, 2. 
