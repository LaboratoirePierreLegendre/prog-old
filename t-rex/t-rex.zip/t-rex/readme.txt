Program T-REX (Tree and Reticulogram Reconstruction)
Version 2.0a1

Vladimir Makarenkov (with contributions from Philippe Casgrain, Olivier Gascuel, Alain Gu�noche, Pierre-Alexandre Landry, Francois-Joseph Lapointe, Bruno Leclerc and Pierre Legendre).
December 2002
e-mail: makarenv@magellan.umontreal.ca
Department of Biological Sciences
University of Montreal

What does T-REX do?

This program carries out some algorithms for the reconstruction of additive trees and reticulograms given a dissimilarity matrix. Additive trees can also be inferred from data matrices containing missing values. An additive tree distance or a reticulogram distance is fitted to the given dissimilarity.

As far as additive tree reconstruction is concerned, the program carries out five methods of fitting an additive distance (distance representable by a tree with non-negative edge lengths) to a given dissimilarity.

The following methods are available:

1. ADDTREE by Sattath and Tversky (1977),
2. Neighbor-joining (NJ) method by Saitou and Nei (1987),
3. Unweighted neighbor-joining method (UNJ) by Gascuel (1997),
4. Circular order reconstruction method by Makarenkov and Leclerc (1997, 2000), and 
    Yushmanov (1984),
5. Weighted least-squares method MW by Makarenkov and Leclerc (1999).

The first two methods are the most frequently used methods for inferring
additive trees. The third method, UNJ, uses at each step the same selection
criterion, but more general estimation and reduction formulae than NJ to
infer the tree. The fourth method reconstructs an additive tree using
circular orders of elements associated with a given dissimilarity. This
fitting method, presented in Makarenkov and Leclerc (1997), was inspired by
Yushmanov's (1984) paper which introduced the notion of circular orders of
elements corresponding to the circular (say, clockwise) scanning of leaves
of a tree drawing on the plane. The fifth method, denoted MW, looks for the
best additive tree with respect to dissimilarity and weight matrices
supplied by the user. This method allows for arbitrary weights, which may be
chosen according to one of the classical weighting models proposed in the
literature. The tree obtained by any of the four methods are polished by means of the
procedure of quadratic approximation (see Barthelemy and Guenoche (1991) in
the unweighted case or Makarenkov and Leclerc (1998) in the weighted case)
of edge lengths in order to improve the value of the least-squares criterion
and to avoid negative edge lengths.

As far as additive tree reconstruction from dissimilarity matrices containing missing values, the offers four fitting methods.

The following methods are available:

1. Triangle method by Gu�noche (1999),
2. Ultrametric procedure for estimation of missing values by De Soete (1984) and
     Lapointe and Landry (1997) followed by MW method.
3. Additive procedure for estimation of missing values by Lapointe and Landry (1997)
     followed by MW method.
4. Weighted least-squares method MW by Makarenkov and Leclerc (1999), with an
option giving weights of 1 to the existing entrees and weights of 0 to the missing ones.

With reticulogram reconstruction, see Legendre and Makarenkov (2002), the program first computes a classical additive tree using one of the five available tree reconstruction algorithms. Then, at each step of the reticulogram reconstruction procedure, a reticulation (a new edge) is chosen to minimize the least-squares or the weighted least-squares loss function. That edge is then added to the growing reticulogram. You will find more information about these methods in the Reticulogram reconstruction section.

As results T-REX provides:

1. Tree or reticulogram fitting statistics:
a. The fitted additive or reticulogram distance matrix,
b. The list of the tree or reticulogram edges with their lengths,
c. The values of the (weighted) least-squares criterion, the (weighted) average
    absolute difference, the (weighted) maximum absolute difference and the total
    length of the obtained tree or reticulogram. If reticulogram reconstruction is
    performed the program also provides the values of the (weighted) least-
    squares criterion, as well as the values of the goodness-of-fit criterion Q1 or Q2, see Legendre and Makarenkov (2002) for their definition, 
    for each reticulation added to the basic additive tree.


References:

     Barthelemy, J.P., Guenoche, A. (1991) Trees and proximity
     representations, New York, Wiley.

     Gascuel, O. (1997), Concerning the NJ algorithm and its unweighted
     version UNJ, in Mathematical hierarchies and Biology (B. Mirkin,
     F.R. McMorris, F. Roberts, A. Rzhetsky, eds.), DIMACS Series in
     Discrete Mathematics and Theoretical Computer Science, Amer. Math.
     Soc., Providence, RI, 1997, 149-171.

     Legendre, P., Makarenkov, V. (2002), Reconstruction of biogeographic
     and evolutionary networks using reticulograms, Systematic Biology, 
     51(2), 199-216.

     Makarenkov, V. (1997), Proprietes combinatoires des distances
     d'arbres. Algorithmes et applications, Ph.D. Thesis, EHESS, Paris,
     and Institute of Control Sciences, Moscow.

     Makarenkov, V., Leclerc, B. (1997), Tree metrics and their
     circular orders: some uses for the reconstruction and fitting of
     phylogenetic trees, in Mathematical hierarchies and Biology (B.
     Mirkin, F.R. McMorris, F. Roberts, A. Rzhetsky, eds.), DIMACS
     Series in Discrete Mathematics and Theoretical Computer Science,
     Amer. Math. Soc., Providence, RI, 1997, 183-208.

     Makarenkov, V. and Leclerc, B. (1999), An algorithm for the fitting
     of a phylogenetic tree according to a weighted least-squares criterion,
     Journal of Classification, 16, 1, 3-26.

     Makarenkov, V. and Leclerc, B. (2000), Comparison of additive trees
     using circular orders, Journal of Computational Biology, 7, 5, 731-744.

     Saitou, N., Nei, M. (1987), The neighbor-joining method: a new
     method for reconstructing phylogenetic trees, Molecular Biology
     Evolution, 4, 406-425.

     Sattath, S., Tversky, A. (1977), Additive similarity trees,
     Psychometrika 42, 319-345.

     Yushmanov, S.V. (1984), Construction of a tree with p leaves from
     2p-3 elements of its distance matrix (russian), Matematicheskie
     Zametki 35, 877-887
