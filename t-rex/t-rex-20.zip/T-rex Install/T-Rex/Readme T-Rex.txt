========================================================================
           Program T-REX (Tree and Reticulogram reconstruction)
                   Version 2.0a1 FOR Windows 9x/NT/2000
========================================================================

Vladimir Makarenkov (with contributions from Philippe Casgrain, Olivier Gascuel,
		     Alain Gu�noche, Pierre-Alexandre Landry, Francois-Joseph Lapointe,
		     Bruno Leclerc and Pierre Legendre).
December 2000
Departement de Sciences Biologiques
University of Montreal

/////////////////////////////////////////////////////////////////////////////

Using T-REX is easy !

	1. Start the program by double-clicking its icon.
	
	2. Open a dissimilarity matrix file (in ASCII format).
	
	3. Look at the resulting window to ensure that this is the matrix you wanted.
	
	4. Select Reconstruct a tree, Reconstruct a tree from a partial matrix
	   or Reconstruct a reticulogram option in the T-REX menu.
	
	5. Choose one of the available tree reconstruction methods for your additive tree
	   (left-hand side of the dialog), and select what to output on the right-hand
	   side.

           T-REX will now compute the fitted distance matrix, tree or reticulogram
	   edges and tree or reticulogram statistics, which will appear in a new text
	   window. A second window will contain the tree or reticulogram drawing.
	   You can copy the information appearing in both windows to the clipboard,
	   to be pasted into your favorite text or picture editor. The information in
	   both windows can also be saved and printed.

/////////////////////////////////////////////////////////////////////////////

General Information about T-REX

	This program carries out some algorithms for the reconstruction of additive trees
        and reticulograms given a dissimilarity matrix. Additive trees can also be inferred
        from data matrices containing missing values. An additive tree distance or a
        reticulogram distance is fitted to the given dissimilarity.

	As far as additive tree reconstruction is concerned, the program carries out five
        methods of fitting an additive distance (distance representable by a tree with
        non-negative edge lengths) to a given dissimilarity.

	The following methods are available:

		1. ADDTREE by Sattath and Tversky (1977),
		2. Neighbor-joining (NJ) method by Saitou and Nei (1987),
		3. Unweighted neighbor-joining method (UNJ) by Gascuel (1997),
		4. Circular order reconstruction method by Makarenkov and Leclerc (1997), and 
    		   Yushmanov (1984),
		5. Weighted least-squares method MW by Makarenkov and Leclerc (1999).

	You will find more information about these methods in the Additive Tree
        reconstruction section of the T-REX Help manuel.

	As far as additive tree reconstruction from dissimilarity matrices containing
        missing values, the offers four fitting methods.

	The following methods are available:

		1. Triangle method by Gu�noche (1999),
		2. Ultrametric procedure for estimation of missing values by De Soete (1984) and
     		   Landry and Lapointe (1996) followed by MW method.
		3. Additive procedure for estimation of missing values by Landry and Lapointe (1996)
     		   followed by MW method.
		4. Weighted least-squares method MW by Makarenkov and Leclerc (1999), performed with the
		   option giving weights of 1 to the existing entrees and weights of 0 to the missing ones.

	With reticulogram reconstruction, the program first computes a classical
        additive tree using one of the five available tree reconstruction algorithms.
        Then, at each step of the reticulogram reconstruction procedure, a reticulation
        (i.e., new edge) is chosen to minimize the least-squares loss function. That edge is
        then added to the growing reticulogram. You will find more information about these
        methods in the Reticulogram reconstruction section of the T-REX Help manuel.

	As results T-REX provides:

		1. A window with the tree or reticulogram fitting statistics:
			a. The fitted additive or reticulogram distance matrix,
			b. The list of the tree or reticulogram edges with their lengths,
			c. The values of the (weighted) least-squares criterion, the (weighted) average
    			   absolute difference, the (weighted) maximum absolute difference and the total
           		   length of the obtained tree or reticulogram. If reticulogram reconstruction is
    			   performed the program also provides the values of the (weighted) least-
    			   squares criterion, as well as the values of the goodness-of-fit criterion Q1 or Q2 
    			   for each reticulation added to the basic additive tree.
		2. A window with the tree or reticulogram drawing. hierarchical, Axial and Radial types of
                   tree drawing have been implemented in T-REX. The tree edges are depicted by full lines
		   and the supplementary edges (reticulations) are depicted by dashed lines.

/////////////////////////////////////////////////////////////////////////////

References

	Barth�lemy, J.P., Gu�noche, A. (1991), Trees and proximity representations, New York, Wiley.

	Cavalli-Sforza, L.L., Edwards, A.W.F. (1967), Phylogenetic analysis models and estimation procedures, American Journal of Human Genetics, 19, 233-257.

	De Soete, G. (1984), Additive-Tree Representations of Incomplete Dissimilarity Data, Quality and Quantity, 18, 387-393.

	Fitch, W.M., Margoliash, E. (1967), A non-sequential method for constructing trees and hierarchical classifications, Journal of Molecular Evolution, 18, 30-37.

	Gascuel, O. (1997), Concerning the NJ algorithm and its unweighted version UNJ, in Mathematical hierarchies and Biology (B. Mirkin, F.R. McMorris, F. Roberts, A. Rzhetsky, eds.),
		DIMACS Series in Discrete Mathematics and Theoretical Computer Science, Amer. Math. Soc., Providence, RI, 1997, 149-171.

	Gu�noche, A., and Grandcolas, S. (1999), Approximation par arbre d'une distance partielle, MathEmatiques,Informatique et Sciences humaines, 146, 51-64. 

	Lapointe, F.J., Legendre, P., Rohlf, J., Smouse, P., and Sneath, P. (2000), Special Section dedicated to the reticulate evolution, Journal of Classification, 17, 153-183.

	Landry, P. A., Lapointe, F.-J., Kirsch, J. (1996), Estimating phylogenies from distance matrices: additive is superior to ultrametric estimation, Molecular Biology and Evolution, 13 (6), 818-823.

	Makarenkov, V. (1997), Proprietes combinatoires des distances d'arbres. Algorithmes et applications, Ph. D. Thesis (French), EHESS, Paris, and Institute of Control Sciences, Moscow.

	Makarenkov, V., Leclerc, B. (1997), Tree metrics and their circular orders: some uses for the reconstruction and fitting of phylogenetic trees, in Mathematical hierarchies and Biology (B.
		Mirkin, F.R. McMorris, F. Roberts, A. Rzhetsky, eds.), DIMACS Series in Discrete Mathematics and Theoretical Computer Science, Amer. Math. Soc., Providence, RI, 1997, 183-208.

	Makarenkov, V., Leclerc, B. (1999), An algorithm for the fitting of a tree metric according to a weighted least-squares criterion, Journal of Classification 16, 3-26.

	Makarenkov, V., Legendre, P. (1999), General Network Representation of a Dissimilarity Matrix: Adding Reticulations to an Additive tree, research rapport,
	 	submitted.

	Makarenkov, V., Legendre, P. (2000), Improving the additive tree representation of a dissimilarity matrix using reticulations, in Kiers H.A.L., Rasson J.-P., Groenen P.J.F.
		and Schader M. (Edts), Data Analysis Classification and Related Methods, Springer, 35-40.

	Saitou, N., Nei, M. (1987), The neighbor-joining method: a new method for reconstructing phylogenetic trees, Molecular Biology Evolution, 4, 406-425.

	Sattath, S., Tversky, A. (1977), Additive similarity trees, Psychometrika 42, 319-345.

	Sonea, S. and Panisset, M. (1976), Pour une nouvelle bacteriologie. Revue Canadienne de Biologie, 35, 103-167.

	Swofford, D.L., Olsen, G. L. (1990), Phylogeny Reconstruction, in: D.M. Hill, and C. Moritz, eds., Molecular Systematics, Sunderland, MA: Sinauer Associates, 411-505.

	Yushmanov, S.V. (1984), Construction of a tree with p leaves from 2p-3 elements of its distance matrix (Russian), Matematicheskie Zametki 35, 877-887.
