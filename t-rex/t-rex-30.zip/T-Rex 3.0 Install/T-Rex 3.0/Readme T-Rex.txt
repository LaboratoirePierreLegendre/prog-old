========================================================================
           Program T-Rex (Tree and Reticulogram reconstruction)
               Version 3.0a1 for Windows 9x/NT/2000/ME/XP
========================================================================

Vladimir Makarenkov (with contributions from Alix Boc, Philippe Casgrain, Abdoulaye Banir� Diallo, Olivier Gascuel, Alain Gu�noche, Pierre-Alexandre Landry, Francois-Joseph Lapointe, Bruno Leclerc and Pierre Legendre).

May 2003
Departement d'Informatique
Universit� du Quebec � Montreal

/////////////////////////////////////////////////////////////////////////////

Using T-Rex is easy !

	1. Start the program by double-clicking its icon.
	
	2. Open a dissimilarity matrix file (in ASCII format).
	
	3. Look at the resulting window to ensure that this is the matrix you wanted.
	
	4. Select Reconstruct a tree or Reconstruct a reticulogram or Reconstruct an HGT            reticulogram or Reconstruct a tree from partial data in the T-REX menu.
	
	5. Choose one of the available tree reconstruction methods for your additive tree
	   (left-hand side of the dialog), and select what to output on the right-hand
	   side.

           T-REX will now compute the fitted distance matrix, tree or reticulogram
	   edges and tree or reticulogram statistics, which will appear in a new text
	   window. A second window will contain the tree or reticulogram drawing.
	   You can copy the information appearing in both windows to the clipboard,
	   to be pasted into your favorite text or picture editor. The information in
	   both windows can also be saved and printed.

/////////////////////////////////////////////////////////////////////////////

General Information about T-REX

This program includes a number of popular algorithms for the reconstruction of additive (i.e., phylogenetic) trees and reticulograms from a given dissimilarity matrix. Additive trees can also be inferred from data matrices containing missing values. An additive tree distance or a reticulogram distance is fitted to the given dissimilarity.

As far as additive tree reconstruction is concerned, the program carries out six methods of fitting an additive distance (distance representable by a tree with non-negative edge lengths) to a given dissimilarity.

The following methods are available:


1. ADDTREE by Sattath and Tversky (1977),

2. Neighbor-joining (NJ) method by Saitou and Nei (1987),
3. Bio Neighbor-Joining method (BioNJ) by Gascuel (1997),
4. Unweighted neighbor-joining method (UNJ) by Gascuel (1997),

5. Circular order reconstruction method by Makarenkov and Leclerc (1997), and 
    Yushmanov (1984),

6. Weighted least-squares method MW by Makarenkov and Leclerc (1999).

You will find more information about these methods in the Additive Tree reconstruction section.

As far as additive tree reconstruction from dissimilarity matrices containing missing values, the offers four fitting methods.

The following methods are available:


1. Triangle method by Gu�noche and Leclerc (2001),
2. Ultrametric procedure for estimation of missing values by De Soete (1984) and
     Lapointe and Landry (1997) followed by NJ.
3. Additive procedure for estimation of missing values by Lapointe and Landry (1997)
     followed by NJ.

4. Weighted least-squares method MW* by Makarenkov and Lapointe (2003) giving
     weights of 1 to the existing entrees and weights of 0.5 (if reestimated) or 0 (if the
     reestimation is not possible) to the missing ones.

You will find more information about these methods in the section Additive Tree reconstruction from matrices with missing values.

With reticulogram reconstruction, the program first computes a phylogenetic tree using one of the six available tree reconstruction algorithms. Then, at each step of the reticulogram reconstruction procedure, a reticulation (a new edge) is chosen to minimize the least-squares or the weighted least-squares loss function. That edge is then added to the growing reticulogram. You will find more information about these methods in the Reticulogram reconstruction section. When HGT (horizontal gene transfer) reticulogram reconstruction option the program maps the gene tree into the species tree using the least-squares. Horizontal transfers of the considered gene are then shown in the species tree.

As results T-REX provides:

1. A window with the tree or reticulogram fitting statistics:

a. The fitted additive or reticulogram distance matrix,
b. The list of the tree or reticulogram or HGT edges with their lengths,

c. The values of the (weighted) least-squares criterion, the (weighted) average
    absolute difference, the (weighted) maximum absolute difference and the total
    length of the obtained tree or reticulogram. If reticulogram reconstruction is
    performed the program also provides the values of the (weighted) least-
    squares criterion, as well as the values of the goodness-of-fit criterion Q1 or Q2 
    for each reticulation added to the basic additive tree.

2. A window with the tree or reticulogram drawing. The tree edges are depicted by full lines and the supplementary edges (reticulations or HGTs) are depicted by dashed lines.

/////////////////////////////////////////////////////////////////////////////

References


Barthelemy, J.P., Guenoche, A. (1991), Trees and proximity representations, New York, Wiley.

Boc, A. and Makarenkov, V. (2003), New Efficient Algorithm for Detection of Horizontal Gene Transfer Events, to appear in WABI 2003 proceedings.

Cavalli-Sforza, L.L., Edwards, A.W.F. (1967), Phylogenetic analysis models and estimation procedures, American Journal of Human Genetics, 19, 233-257.

De Soete, G. (1984), Additive-Tree Representations of Incomplete Dissimilarity Data, Quality and Quantity, 18, 387-393.

Fitch, W. M., Margoliash, E. (1967), A non-sequential method for constructing trees and hierarchical classifications, Journal of Molecular Evolution, 18, 30-37.

Gascuel, O. (1997), Concerning the NJ algorithm and its unweighted version UNJ, in Mathematical hierarchies and Biology (B. Mirkin, F.R. McMorris, F. Roberts, A. Rzhetsky, eds.), DIMACS Series in Discrete Mathematics and Theoretical Computer Science, Amer. Math. Soc., Providence, RI, 1997, 149-171.

Gascuel, O. (1997), BIONJ: an improved version of the NJ algorithm based on a simple model of sequence data, Mol. Biol. Evol., 14(7), 685-695.

Gu�noche, A., and Grandcolas, S. (1999), Approximation par arbre d'une distance partielle, Math�matiques,Informatique et Sciences humaines, 146, 51-64. 

Landry, P. A. and Lapointe, F.-J. (1996), Estimating phylogenies from distance matrices: additive is superior to ultrametric estimation, Molecular Biology and Evolution, 13 (6), 818-823.

Landry, P.-A., and Lapointe, F.-J. (1997), Estimation of Missing Distances in Path-Length Matrices: Problems and Solutions. Pp. 209-224, in Mathematical hierarchies and Biology (B. Mirkin, F.R. McMorris, F. Roberts, A. Rzhetsky, eds.), DIMACS Series in Discrete Mathematics and Theoretical Computer Science, Amer. Math. Soc., Providence, RI, 1997, 209-224.

Lapointe, F.J.,. Legendre, P., Rohlf, J., Smouse, P., and Sneath, P. (2000), Special Section dedicated to the reticulate evolution, to appear in the Journal of Classification.

Legendre, P. 2000. Biological applications of reticulation analysis, Journal of Classification 17, 153-157.

Legendre, P., and V. Makarenkov. 2002. Reconstruction of Biogeographic and Evolutionary Networks Using Reticulograms. Systematic Biology 51, 199-216.

Levasseur, C., Landry, P. A. and Lapointe, (2000), Estimating Trees from Incomplete Distance Matrices: a Comparison of Two Methods, Data analysis, Classification and Related Methods (H. A.L. Kiers, J.-P. Rasson, P. J.F. Groenen, M. Schader, eds), 149-154.

Levasseur, C., Landry, P. A., Makarenkov, V., Kirsch, J. A. W. and Lapointe, F.-J. (2003), Incomplete distance matrices, supertrees and bat phylogeny, Molecular Phylogenetics and Evolution, 239-246.

Makarenkov, V. (1997), Proprietes combinatoires des distances d'arbres. Algorithmes et applications, Ph. D. Thesis (French), EHESS, Paris, and Institute of Control Sciences, Moscow.

Makarenkov, V., Leclerc, B. (1997), Tree metrics and their circular orders: some uses for the reconstruction and fitting of phylogenetic trees, in Mathematical hierarchies and Biology (B. Mirkin, F.R. McMorris, F. Roberts, A. Rzhetsky, eds.), DIMACS Series in Discrete Mathematics and Theoretical Computer Science, Amer. Math. Soc., Providence, RI, 1997, 183-208.

Makarenkov, V., Leclerc, B. (1999), An algorithm for the fitting of a tree metric according to a weighted least-squares criterion, Journal of Classification 16, 3-26.

Makarenkov, V., and B. Leclerc. (2000), Comparison of additive trees using circular orders. Journal of Computational Biology 7, 731-744.

Makarenkov, V. (2001), T-Rex: reconstructing and visualizing phylogenetic trees and reticulation networks. Bioinformatics 17, 664-668.

Makarenkov, V., Legendre, P. and Desdevises, Y. (2003), Modeling phylogenetic relationships using reticulated networks, to appear in Zoologica Scripta.

Makarenkov, V. and Legendre, P. (2003), From a phylogenetic tree to a reticulated network, to appear in the Journal of Computational Biology.

Makarenkov, V. and Lapointe, F.-J. (2003), A weighted least-squares approach for inferring phylogenies from incomplete distance matrices and computing supertrees from the combination of partially overlapping path-length matrices, submitted to Bioinformatics.

Saitou, N., Nei, M. (1987), The neighbor-joining method: a new method for reconstructing phylogenetic trees, Molecular Biology Evolution, 4, 406-425.

Sattath, S., Tversky, A. (1977), Additive similarity trees, Psychometrika 42, 319-345.

Sonea, S. and Panisset, M. (1976), Pour une nouvelle bacteriologie. Revue Canadienne de Biologie, 35, 103-167.

Swofford, D. L., and G. L. Olsen. 1996. Phylogeny reconstruction, 407-514. In D. M. Hill eds. Molecular Systematics. Sinauer.

Yushmanov, S.V. (1984), Construction of a tree with p leaves from 2p-3 elements of its distance matrix (Russian), Matematicheskie Zametki 35, 877-887.