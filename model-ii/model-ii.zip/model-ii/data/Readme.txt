This folder contains the data files used in the examples of the user's guide.

Example 1: 'Hospital/Observed,forecast/54x2', 54 rows, 2 columns; x comes first.

Example 2: 'Rays and bivalves (20x2)', 20 rows, 2 columns; x comes first.

Example 3: 'Fish egg production (11x2)', 11 rows, 2 columns; x comes first.

Example 4: 'Mesple et al./100x2 (x,y)', 100 rows, 2 columns; x comes first.

Example 5: 'Random numbers (100x2)', 100 rows, 2 columns; x comes first.

Pierre Legendre
January 2000
