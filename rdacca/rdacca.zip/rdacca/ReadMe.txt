ReadMe for RdaCca

The two example files are from Table 11.3 in Legendre, P. and L.
Legendre. 1998. Numerical Ecology, 2nd Ed. Elsevier. Output files are
reproduced in Table 11.4 of the same book.

The user's guide is in Word 6 for Macintosh and Windows format.

The program RDACCA5.EXE can deal with as many as 500 objects, at the cost of 
about 26MB of memory. The less RAM-hungry, 100-objects versions is called
RDACCA.EXE.

