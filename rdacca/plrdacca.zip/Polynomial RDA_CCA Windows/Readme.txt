EXAMPLE FILES FOR POLYNOMIAL RDA/CCA

The three example files are from the following sources:

Example1 (Polynomial RDA in output file) - Table 1 of Makarenkov & Legendre,  
         1999 (see also Table 10.5 and 13.3 of Legendre & Legendre, 1998).
           

Example2 (Polynomial RDA in output file) - Table 3 of Makarenkov & Legendre,  
         2001 (see also Tables 2-4 of Aart (van der) & Smeenk-Enserink, 1975).


Example3 (Polynomial CCA in output file) - Table 3 of Makarenkov & Legendre,  
         2001 (see also Tables 2-4 of Aart (van der) & Smeenk-Enserink, 1975).



THE USER'S GUIDE AVAILABLE IS IN PDF (Acrobat Reader) FORMAT.
															REFERENCES

Aart, P. J. M. (van der) & N. Smeenk-Enserink. 1975. Correlations between 
 distributions of hunting spiders (Lycosidae, Ctenidae) and environmental 
 characteristics in a dune area. Neth. J. Zool. 25: 1-45.

Legendre, P. & L. Legendre. 1998. Numerical ecology, 2nd English edition. 
 Elsevier Science BV, Amsterdam. 

Makarenkov, V. & P. Legendre. 1999. Une methode d'analyse canonique non-lineaire
 et son application a des donnees biologiques. Mathematiques, Informatique et
 Sciences Humaines, 37e annee, 147: 135-147.

Makarenkov, V. & P. Legendre. 2001. Nonlinear redundancy analysis and canonical
 correspondence analysis based on polynomial regression, to appear in Ecology.
