Program Corr_permute                                  December 2000

This program computes a matrix of Pearson correlations among variables, with test
of significance of the correlation coefficients obtained by permuting the data in
one of the two variables in each pair. The theory of this type of test is
presented, for instance, in Legendre & Legendre (1998, Section 1.2).

Input data file: the objects are the rows of this file; the variables are the
columns. The program is presently dimensioned for 1000 objects and 101 variables.

There are three types of output files:

File 'Correlat.txt' contains the square correlation matrix.
File 'Prob.txt' contains the square matrix of permutational probabilities.
File 'CorrProb.txt' contains both the correlations and the probabilities.

Here is an example of a 'CorrProb.txt' file. It contains the correlations among 5
variables made of random normal deviates. The correlation matrix is of size (5 x
5); the values on the diagonal are 1.00000. The corresponding permutational
probability is printed under each correlation value. The diagonal probabilities
(0.0000) were not computed; they are trivial values devoid of interest.

 Square correlation matrix. For each correlation:
 Line 1 = correlation,  line 2 = probability (    99 permutations)

  1.00000  0.11873  0.00299  0.04744  0.24603
   0.0000   0.3900   1.0000   0.6900   0.1000 

  0.11873  1.00000  0.24107  0.05241  0.09498
   0.3900   0.0000   0.1200   0.7400   0.5600 

  0.00299  0.24107  1.00000  0.28926 -0.02828
   1.0000   0.1200   0.0000   0.0500   0.8800 

  0.04744  0.05241  0.28926  1.00000  0.01057
   0.6900   0.7400   0.0500   0.0000   0.9500 

  0.24603  0.09498 -0.02828  0.01057  1.00000
   0.1000   0.5600   0.8800   0.9500   0.0000 


If necessary, the output files can be transferred to a spreadsheet program where
identifiers may be added to the rows and columns of the correlation matrix.

Reference

Legendre, P. and L. Legendre. 1998. Numerical ecology, 2nd English edition.
Elsevier Science BV, Amsterdam.




Pierre Legendre,
Departement de sciences biologiques,
Universite de Montreal.
