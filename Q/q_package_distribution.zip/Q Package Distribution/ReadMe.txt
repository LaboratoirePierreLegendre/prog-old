Read Me for the Q Package

The Q Package is no longer available from our web page because of significant Quality Assurance issues. It worked for the purpose we used it for (analyzing our sonar datasets), but it was built using antiquated technologies (CodeWarrior Pascal for the engine, Delphi Pascal for the UI) and required significant hand-holding to not crash. It would be best re-written in a high-level scripting language like Python, for instance. Unfortunately, this is not one of our priorities right now.

The Q Package was used in the following papers:
	•	Legendre, P., K. E. Ellingsen, E. Bjørnbom & P. Casgrain. 2002. Acoustic seabed classification: improved statistical method. Canadian Journal of Fisheries and Aquatic Sciences 59 (7): 1085-1089. 
	•	Legendre, P. 2002. Acoustic seabed classification methodology: a user's statistical comparison. Report, Département de sciences biologiques, Université de Montréal. 17 pp.

The Q Package was intended to be a DLL containing most (all?) of the R Package's statistical routines, as compiled Windows code. A Delphi front-end linking against this DLL was created. Its goal was to prepare the data (in tabular format), send it to the DLL for various computations (e.g. Principal Coordinates) and display the results, either matrices or output text.

In this archive, you will find two folders:

	*	Q Package Source
		
		The source code for the aforementioned DLL. We cannot find the source for the Delphi front-end, but unless you have Delphi, that would not help you in most cases.
		The compiler used was Metrowerks CodeWarrior Pascal, which has been discontinued for some time.
		
	* Distribution
	
		A binary version of the front end + DLL combo, along with some sample data. This is what was on our web site, which was pulled because of QA issues. It is also what we used for the articles.

No included in this package is the source code for the QTC parser that was used to massage the sonar backscatter data from raw output to a suitable rectangular matrix (so it could be fed to the Q Package). The parser was written in Pascal, a wholly unsuitable language for this task. If you are truly interested in it, email us and we will give you more details.

We are distributing this under the MIT Open Source license. If you should do anything interesting with it, we would be delighted to hear from you.

--

Philippe Casgrain, casgrain@exchange.umontreal.ca
Pierre Legendre, Pierre.Legendre@umontreal.ca

October 2008