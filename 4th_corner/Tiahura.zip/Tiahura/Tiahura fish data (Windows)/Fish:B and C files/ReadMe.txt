Files containing the indicator variables for the rows and columns

The nominal variables in file B (indicator variables for the species) must EACH be 
presented to the 4th_corner program in a SEPARATE FILE. Two forms are equally 
acceptable by the program:

• a multistate variable can be coded in a single column, 
• or in the form of several binary variables.

For example, variable 1 in file B "Feeding habits" has 7 states. It can be presented 

• either coded into a single column as in file "B1(280x1)", with states 1 to 7,
• or as 7 binary (0-1) variables as in file "B1(280x7)".

The indicator variables for the sites (file C) are quantitative. They are presented 
in two separate files for convenience of the analysis: 
"C1+C2(2x22)" and "C3-C10%(8x22)"

                                -----------------

Please refer to the following papers if you use or refer to this data set in 
a thesis or a scientific publication:

Galzin, R. & P. Legendre. 1987. The fish communities of a coral reef transect. 
Pacific Science 41: 158-165.

Legendre, P., R. Galzin & M. Harmelin-Vivien. Relating behavior to habitat: 
Solutions to the fourth-corner problem. Ecology (in press).

Pierre Legendre             Legendre@ere.umontreal.ca                June 1996
René Galzin                 pol@univ-perp.fr
Mireille Harmelin-Vivien    Harmelin@com.univ-mrs.fr
